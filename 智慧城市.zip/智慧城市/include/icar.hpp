#pragma once

#include "fsm/busy.hpp"
#include "fsm/curve.hpp"
#include "fsm/cross.hpp"
#include "fsm/fine.hpp"
#include "fsm/fork.hpp"
#include "fsm/park.hpp"
#include "fsm/slow.hpp"
#include "fsm/people.hpp"
#include "utils/show.hpp"
#include "utils/loop.hpp"
#include "utils/detection.hpp"
#include "ctrl/predeal.hpp"
#include "ctrl/center.hpp"
#include "ctrl/motion.hpp"
#include "com/uart.hpp"        //串口通信驱动

using namespace std;
using namespace cv;

class Icar
{
private:
    /**
     * @brief 状态机管理
     *
     */
    struct FsmFactory
    {
        shared_ptr<FsmBusy> busy;   // 避障控制
        shared_ptr<FsmCross> cross; // 斑马线停车控制
        shared_ptr<FsmCurve> curve; // 连续弯道控制
        shared_ptr<FsmSlow> slow;   // 慢行区控制
        shared_ptr<FsmFine> fine;   // 禁行区控制
        shared_ptr<FsmFork> fork;   // 停车场岔路控制
        shared_ptr<FsmPark> park;   // 停车场控制
        shared_ptr<FsmPeople> people;   // 停车场控制
    };

    FsmFactory fsmFactory;                // 状态机管理
    shared_ptr<Predeal> predeal;          // 图像预处理类
    shared_ptr<Show> show;                // 初始化UI显示窗口
    shared_ptr<cv::VideoCapture> capture; // Opencv相机类
    shared_ptr<Params> params;            // 车辆状态参数（FSM共享传递）
    shared_ptr<Uart> uart;                // 串口通信类
    shared_ptr<Center> center;            // 控制中心处理类
    shared_ptr<Motion> motion;            // 运动控制器
    shared_ptr<Detection> detection;      // 目标检测类
    shared_ptr<Loops> loops;              // 子线程循环

    // 全局共享数据链
    cv::Mat imgShare;
    std::mutex mtxImg;
    std::condition_variable cvImg;
    std::atomic<bool> readyImg{false};
    std::mutex mtxRes;
    std::atomic<bool> readyRes{false};

    /**
     * @brief AI 模型推理
     *
     */
    void runModel()
    {
        std::unique_lock<std::mutex> lock(mtxImg);
        cvImg.wait(lock, [this]
                   { return readyImg.load(); });
        cv::Mat img = imgShare.clone(); // 图像拷贝出来再释放锁
        readyImg = false;
        lock.unlock();

        // 启动AI推理
        detection->inference(img);
        std::lock_guard<std::mutex> lock_result(mtxRes);
        params->results = detection->results;
        readyRes = true;
    }

    /**
     * @brief 有限状态机任务执行
     *
     */
    void runFsm(Mat &img, Mat &IMG)
    {
        fsmFactory.cross->run(img); // 斑马线停车识别与规划
        params->mode = fsmFactory.cross->getMode();



        if (params->mode == FsmMode::NORMAL || params->mode == FsmMode::PARK) // 停车场图像处理
        {
            fsmFactory.park->run(img);
            params->mode = fsmFactory.park->getMode();
            if(params->mode == FsmMode::PARK)
            {
                fsmFactory.park->searchgate(IMG); 

            }
            //if(params->mode == FsmMode::PARK)
            //    cout<<"停车"<<endl;
        }
        
        if (params->mode == FsmMode::NORMAL || params->mode == FsmMode::BUSY)
        {
            fsmFactory.busy->run(img); // 施工区识别与规划
            params->mode = fsmFactory.busy->getMode();
            // if(params->mode == FsmMode::BUSY)
            // {
            //     fsmFactory.busy->searchCones(IMG);
            // }
        }

        if (params->mode == FsmMode::NORMAL || params->mode == FsmMode::SLOW) // 慢行区识别与规划
        {
            fsmFactory.slow->run(img); 
            params->mode = fsmFactory.slow->getMode();    
        }


        //粉色
        if(params->config.purple_count)
        {
            fsmFactory.people->purple_time++;
            
            if(fsmFactory.people->purple_time>params->config.purple_time)
            {
                params->config.purple_count =false;
                fsmFactory.people->purple_time=0;
            }

        }

        //红色
        if(params->config.red_count)
        {
            fsmFactory.people->red_time++;

            if(fsmFactory.people->red_time >params->config.red_time)
            {
                params->config.red_count = false;
                fsmFactory.people->red_time = 0;
            }
        }
        //cout<<"red_time:"<<fsmFactory.people->red_time<<endl;
        //cout<<"purple_time:"<<fsmFactory.people->purple_time<<endl;
        if (params->mode == FsmMode::NORMAL || params->mode == FsmMode::PEOPLE) // 行人识别与规划
        {
            fsmFactory.people->run(img); 

            if(fsmFactory.people->step == fsmFactory.people->Step::NONE)
            {      
                //粉色
                if(params->config.purple_enable&&fsmFactory.people->purple_time==0)
                {
                    fsmFactory.people->find_purple(IMG);
                }
                // else if(!params->config.purple_enable)
                // {
                //     fsmFactory.people->find_purple(IMG);
                // }
                
                
                //红色
                if(params->config.red_enable&&fsmFactory.people->red_time==0)
                {
                    fsmFactory.people->find_red(IMG);
                }
                else if(!params->config.red_enable)
                {
                    fsmFactory.people->find_red(IMG);
                }
                
            }
                
            params->mode = fsmFactory.people->getMode();    
        }


        if (params->mode == FsmMode::NORMAL || params->mode == FsmMode::FINE)
        {
            fsmFactory.fine->run(img); // 禁行区识别与规划
            params->mode = fsmFactory.fine->getMode();
            //if(params->mode == FsmMode::FINE)
            //    cout<<"结束任务"<<endl; 
        }

        if (params->mode == FsmMode::NORMAL || params->mode == FsmMode::CURVE ||params->mode == FsmMode::CROSS) // 连续弯道
        {
            fsmFactory.curve->run(img);
            params->mode = fsmFactory.curve->getMode();   
            //if(params->mode == FsmMode::CURVE)
            //    cout<<"弯道"<<endl;         
        }
        
        if (params->mode == FsmMode::NORMAL || params->mode == FsmMode::FORK) // 岔路识别与规划
        {
            fsmFactory.fork->run(img);
            params->mode = fsmFactory.fork->getMode();
            //if(params->mode == FsmMode::FORK)
            //    cout<<"岔路"<<endl;
        }


            




    }

public:
    /**
     * @brief 参数初始化
     *
     */
    Icar()
    { 
        params = make_shared<Params>();                        // 初始化参数
        center = make_shared<Center>();                        // 控制中心处理类
        motion = make_shared<Motion>();                        // 运动控制器
        predeal = make_shared<Predeal>(params->config.binary); // 图像预处理类       
        detection = make_shared<Detection>(params->config.model,params->config.score); // AI模型初始化
        
        uart = make_shared<Uart>("/dev/ttyUSB0"); // 初始化串口驱动

        // USB转串口初始化： /dev/ttyUSB0
        int ret = uart->open();
        if (ret != 0) 
        {
            printf("[Error] Uart Open failed!\n");
            exit(-1);
        }
        uart->buzzerSound(uart->BUZZER_OK); // 祖传提示音效

        // 相机初始化
        // USB摄像头初始化
        if (params->config.debug)
            capture = make_shared<cv::VideoCapture>(params->config.video); // 打开本地视频
        else
            capture = make_shared<cv::VideoCapture>("/dev/video0"); // 打开摄像头

        if (!capture->isOpened())
        {
            printf("[Error]: Can not open video device!!!\n");
            exit(-1);
        }

        capture->set(CAP_PROP_FOURCC, VideoWriter::fourcc('M','J','P','G'));
        capture->set(cv::CAP_PROP_FRAME_WIDTH, COLSCAMERA);  // 设置图像分辨率
        capture->set(cv::CAP_PROP_FRAME_HEIGHT, ROWSCAMERA); // 设置图像分辨率
        capture->set(cv::CAP_PROP_FPS, 120);                  // 设置帧率

        if (params->config.show)
            show = make_shared<Show>(4); // 调试UI初始化

        int rate = capture->get(CAP_PROP_FPS);            // 读取图像的帧率
        int width = capture->get(CAP_PROP_FRAME_WIDTH);   // 读取图像的宽度
        int height = capture->get(CAP_PROP_FRAME_HEIGHT); // 读取图像的高度
        cout << "[OK]: " << "Camera Param: frame rate = " << rate << " width = " << width << " height = " << height << endl;

        // FSM有限状态机初始化
        fsmFactory.busy = make_shared<FsmBusy>(params);   // 避障控制实例化
        fsmFactory.cross = make_shared<FsmCross>(params); // 斑马线停车控制实例化
        fsmFactory.curve = make_shared<FsmCurve>(params); // 连续弯道控制实例化
        fsmFactory.slow = make_shared<FsmSlow>(params);   // 慢行区控制实例化
        fsmFactory.fine = make_shared<FsmFine>(params);   // 禁行区控制实例化
        fsmFactory.fork = make_shared<FsmFork>(params);   // 停车场岔路控制实例化
        fsmFactory.park = make_shared<FsmPark>(params);   // 停车场控制实例化
        fsmFactory.people = make_shared<FsmPeople>(params);   // 行人控制实例化

        // 启动AI推理子线程
        loops = make_shared<Loops>("LoopAI", 1.f / 30.f, std::bind(&Icar::runModel, this));
        loops->start(); // RL开始推理

        printf("[OK]: 把风吹到北京!!!\n");
    };
    ~Icar() {};

    /**
     * @brief 程序主循环
     *
     */
    void running()
    {
        //[01] 视频源读取
        cv::Mat img;
        
        if (!capture->read(img))
            return;
            
        //[02] 图像存储
        //if (params->config.saveImg && !params->config.debug) // 存储原始图像
            

        //[03] 图像预处理
        cv::Mat imgBin;
        imgBin = predeal->binaryzation(img); // 图像二值化
        predeal->black_border(imgBin);
        /*---------------子线程共享数据，避免浅拷贝-----------------*/
        std::lock_guard<std::mutex> lock(mtxImg);
        imgShare = img.clone();
        readyImg = true;
        cvImg.notify_one();
        /*-------------------------------------------------------*/

        //[04] 赛道识别
        params->track->reset();
        params->track->search(900,imgBin);
        
        
        if(params->mode == FsmMode::PARK)
            params->track->ProcessEdgesToSingleLinein(params->track->pointsEdgeLeft,params->track->pointsEdgeRight);
        else
            params->track->ProcessEdgesToSingleLineout(params->track->pointsEdgeLeft,params->track->pointsEdgeRight);
        //[05] 有限状态机任务执行
        runFsm(imgBin,img);

        //[06] 控制中心计算
        if(fsmFactory.people->left)
            center->style = center->Style::LP;
        else if(fsmFactory.people->right)
            center->style = center->Style::RP;
        else if(params->mode == FsmMode::FORK
        ||fsmFactory.park->step==fsmFactory.park->Step::TRACKIN)
            center->style = center->Style::RIGHT;
        else if(fsmFactory.park->step==fsmFactory.park->Step::ENABLE
            ||fsmFactory.park->step==fsmFactory.park->Step::END
            ||fsmFactory.park->step==fsmFactory.park->Step::TRACKOUT)
            center->style = center->Style::LEFT;
        else
            center->style = center->Style::STRIGHT;
        
            
        center->fitting(params);

        //[07] 车辆运动控制
        motion->poseControl(params);
        motion->speedControl(params);         
        if(params->ctrl.buzzer)
            uart->buzzerSound(uart->BUZZER_WARNNING); // 祖传提示音效
        if(fsmFactory.park->step==fsmFactory.park->Step::ENTER
        ||fsmFactory.park->step==fsmFactory.park->Step::PARKING
        ||fsmFactory.park->step==fsmFactory.park->Step::EXIT)
            params->ctrl.servo = 770;
            
        //cout<<"速度:"<<params->ctrl.speed<<endl;
        //cout<<"前瞻:"<<params->ctrl.forword<<endl;
        //uart->carControl(int(params->ctrl.speed),params->ctrl.servo);
        if(params->config.saveImg)
        {
            params->track->drawImage(img);
            center->drawImage(params, img); // 图像绘制控制路径
            line(img,Point(0,params->ctrl.centerEdge[params->ctrl.forword].y),Point(319,params->ctrl.centerEdge[params->ctrl.forword].y),Scalar(255,0,0),1);
            detection->drawBox(img);        // 图像绘制AI结果

            savePicture(img);
        }
        //[08] 综合显示调试UI窗口
        if (params->config.show) // 综合显示调试UI窗口
        {
            params->track->drawImage(img);
            center->drawImage(params, img); // 图像绘制控制路径
            line(img,Point(0,params->ctrl.centerEdge[params->ctrl.forword].y),Point(319,params->ctrl.centerEdge[params->ctrl.forword].y),Scalar(255,0,0),1);
            detection->drawBox(img);        // 图像绘制AI结果

            show->setNewWindow(1, "AI", img);
            show->setNewWindow(2, "Bin", imgBin);
            //show->setNewWindow(3, "P1", img1);
            //show->setNewWindow(4, "P2", imgBin);
            
            show->show();        // 显示综合绘图
            waitKey(1);
        }
        else // 实车控制
        {
            uart->carControl(int(params->ctrl.speed),params->ctrl.servo);
        }    
    }
};
