#pragma once

#include "fsm/fsm.hpp"

/**
 * @brief 停车场岔路图像识别与规划
 *
 */
class FsmFork : public FSMState
{
public:
  FsmFork(std::shared_ptr<Params> par);
  ~FsmFork();
  void run(Mat &img);
  void show(Mat &img);
  FsmMode getMode();

private:
  /**
   * @brief 场景状态
   *
   */
  enum Step
  {
    NONE = 0, // 未知类型
    ENABLE,   // 场景使能
  };
  Step step = Step::NONE; // 环岛处理阶段
  int time = 0;
  void setStep(Step st);
};