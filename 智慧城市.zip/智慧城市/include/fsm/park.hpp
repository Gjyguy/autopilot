#pragma once

#include "fsm/fsm.hpp"

/**
 * @brief 停车场控制
 *
 */
class FsmPark : public FSMState
{
public:
  FsmPark(std::shared_ptr<Params> par);
  ~FsmPark();
  void run(Mat &img);
  void show(Mat &img);
  
  FsmMode getMode();

//private:
  /**
   * @brief 停车步骤
   *
   */
  enum Step
  {
    NONE = 0, // 未知状态
    ENABLE,   // 停车场使能
    FORKIN,   // 入库岔路转向
    TRACKIN,  // 入库巡线
    ENTER,    // 入库
    PARKING,  // 停车
    EXIT,     // 出库
    TRACKOUT, // 出库巡线
    FORKOUT,  // 出库岔路转向
    END,  // 结束
  };

  Step step = Step::NONE;  // 场景状态
  uint16_t timeout = 0;    // 超时计数器
  Point ptA = Point(0, 0);      // 记录线段的两个端点
  
  void setStep(Step st);

  //补线处理
  int right_up = 0;
  int right_down = 0;

  int left_up = 0;
  int left_down = 0;

  void reset(void);
  bool crossRecognition(Mat &img,bool Left);

  void Searchleft(Mat &img);
  void Left_deal();

  void Searchright(Mat &img);
  void Right_deal();

  //寻找道闸
  bool searchgate(Mat &img);
  bool gate = false;
  int gate_y = 0;
};
