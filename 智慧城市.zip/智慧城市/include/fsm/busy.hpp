#pragma once

#include "fsm/fsm.hpp"

/**
 * @brief 避障（施工区）控制
 *
 */
class FsmBusy : public FSMState
{
public:
  FsmBusy(std::shared_ptr<Params> par);
  ~FsmBusy();
  void run(Mat &img);
  void show(Mat &img);
  bool searchCones(Mat &img); 
  FsmMode getMode();

private:
  bool enable = false;     // 场景检测使能标志
  bool coneleft = false;
  bool coneright = false;
  PredictResult ResultObs; // 避障目标锥桶
  PredictResult resultObs; // 最终避障对象
  void curtailTracking(bool left);
};
