#pragma once

#include "fsm/fsm.hpp"

/**
 * @brief 减速区识别与规划
 *
 */
class FsmPeople : public FSMState
{
public:
  FsmPeople(std::shared_ptr<Params> par);
  ~FsmPeople();
  void run(Mat &img);
  void show(Mat &img);
  FsmMode getMode();

  bool find_purple(Mat &img);
  bool purple_enable = false;

  bool find_red(Mat &img);
  bool red_enable = false;

    /**
   * @brief 场景状态
   *
   */
  enum Step
  {
    NONE = 0, // 未知状态
    ENABLE,   // 场景使能
  };
  Step step = Step::NONE; // 场景状态
  bool left = false;
  bool right = false;
  int red_time = 0;
  int purple_time = 0;

private:
  uint16_t timeout = 0;   // 程序退出计数器
  bool dir = false;
  void setStep(Step st);
  void curtailTracking(bool left);
};