#pragma once

#include "fsm/fsm.hpp"

/**
 * @brief 斑马线停车控制
 *
 */
class FsmCross : public FSMState
{
public:
  FsmCross(std::shared_ptr<Params> par);
  ~FsmCross();
  bool detectCross(Mat &img);
  void run(Mat &img);
  void show(Mat &img);
  FsmMode getMode();

private:
  /**
   * @brief 场景状态
   *
   */
  enum Step
  {
    NONE = 0, // AI未识别
    ENABLE,   // 场景使能
  };

  Step step = Step::NONE; // 场景状态
  int timeout = 0;        // 超时计数器
  int countCross = 0;     // 斑马线屏蔽计数器
  int countInit = 0;      // 起点屏蔽计数器
  int Cross = 0;          // 斑马线计数器
  int time = 0;

  void setStep(Step st);
};
