#pragma once

#include "fsm/fsm.hpp"

/**
 * @brief 连续弯道识别与规划
 *
 */
class FsmCurve : public FSMState
{
public:
  FsmCurve(std::shared_ptr<Params> par);
  ~FsmCurve();
  void run(Mat &img);
  void show(Mat &img);
  FsmMode getMode();

private:
  /**
   * @brief 场景状态
   *
   */
  enum Step
  {
    NONE = 0, // 未知状态
    ENABLE,   // 场景使能
  };
  Step step = Step::NONE; // 场景状态
  int timeout = 0;        // 超时计数器

  void setStep(Step st);
};
