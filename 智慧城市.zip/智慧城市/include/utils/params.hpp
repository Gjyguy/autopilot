#pragma once

#include <string>
#include <iostream>
#include <unistd.h>
#include <cmath>
#include <fstream>
#include "utils/json.hpp"
#include "ctrl/track.hpp"

using namespace std;

/**
 * @brief FSM状态场景
 *
 */
enum class FsmMode
{
    NORMAL, // 基础赛道
    FORK,   // 岔路
    PARK,   // 停车场
    BUSY,   // 施工障碍
    SLOW,   // 慢行区
    CURVE,  // 连续弯道
    FINE,   // 禁行区
    STOP,   // 停车区
    CROSS,  // 斑马线
    PEOPLE,  // 行人
};

/**
 * @brief 车辆控制指令
 *
 */
struct Control
{
    bool buzzer = false;
    bool stop = false;            // 车辆停止运动
    bool back = false;            // 倒车
    
    bool slow = false;            // 车辆减速
    bool curveslow = false;            // 车辆减速
    bool personslow = false;            // 车辆减速

    //斑马线
    bool crossslow = false;
    bool crosssenable = true;

    float P = 1.4;

    int forword = 70;
    uint16_t servo = PWMSERVOMID; // 发送给舵机的PWM
    float speed = 0.0;            // 发送给电机的速度
    int center = COLSIMAGE / 2;   // 控制中心
    vector<Point> centerEdge;    // 赛道中心点集
};
/**
 * @brief 控制器核心参数
 *
 */
struct Config
{
    float speedLow = 1.0;                                 // 智能车最低速:m/s
    float speedSlow = 1.0;                                // 慢性区速度:m/s
    float speedPark = 1.0;                                // 充电站车速
    float speedCurve = 1.0;                               // 连续弯道速度:m/s
    float speedBusy = 1.0;                                // 施工区速度:m/s
    float speedFork = 1.0;                                // 斑马线速度: m/s
    float speedPeople = 1.0;                              // 行人速度: m/s

    int normolforword = 70;

    float turnP = 3.5;                                  // 比例系数：转弯控制量
    float turnD = 3.5;                                  // 微分系数：转弯控制量

    bool show = true;
    bool debug = false;                                 // 调试模式使能
    bool saveImg = false;                               // 存图使能

    bool fork = true;                                   // 岔路使能
    bool fine = true;                                   // 禁行区使能
    bool park = true;                                   // 停车场使能
    bool curve = true;                                  // 连续弯道使能
    bool busy = true;                                   // 施工区使能
    bool slow = true;                                   // 慢行区使能
    bool cross = true;                                  // 斑马线停车使能
    bool people = true;                                 // 行人使能
    
    int cross_Judgment1 = 100;
    int cross_Judgment2 = 140;
    int cross_ParkTime = 20;
    int cross_OutTime = 30;
    int cross_Num = 10;

    int fork_forword = 70;

    int people_forword = 60;
    float people_P = 1.3;
    int people_time = 10;
    bool purple_enable = false;
    bool red_enable = false;
    bool purple_count = false;
    bool red_count = false;
    int purple_time = 15;
    int red_time = 15;
    
    int curve_forword = 80;
    float curve_P = 1.4;

    int slow_forword = 20;
    float slow_P =14;
    int slow_outTime = 150;

    int fine_Time = 20;

    float coneP = 1.5;

    int park_forword =30;
    float park_P =1.1;

    int park_Time = 40;
    int park_Y = 100;
    int park_Topline = 140;

    int gate_Time1 = 30;
    int gate_Y1 = 100;
    int gate_Time2 = 30;
    int gate_Y2 = 100;

    float score = 0.5;                                  // AI检测置信度
    int binary = -1;                                    // 图像二值化阈值
    string model = "../res/models/yolov3_mobilenet_v1"; // 模型路径
    string video = "../res/samples/sample.mp4";         // 视频路径
    
    NLOHMANN_DEFINE_TYPE_INTRUSIVE(Config, speedLow, speedSlow, speedPark, speedCurve, speedBusy, speedFork,speedPeople,
                                   normolforword,
                                   turnP, turnD, show, debug, saveImg, 
                                   fork, fine, park, curve, busy, slow,cross,people,
                                   cross_Judgment1,cross_Judgment2,cross_ParkTime,cross_OutTime,cross_Num,
                                   fork_forword,
                                   people_forword,people_P,people_time,purple_enable,red_enable, purple_count,red_count,purple_time,red_time,
                                   curve_forword,curve_P,
                                   slow_forword,slow_P,slow_outTime,
                                   fine_Time,
                                   coneP,
                                   park_forword,park_P,park_Time,park_Y,park_Topline,
                                   gate_Time1,gate_Y1,gate_Time2,gate_Y2,
                                   score, binary, model, video); // 添加构造函数
};

/**
 * @brief 车辆状态参数（FSM共享传递）
 *
 */
struct Params
{
public:
    /**
     * @brief Construct a new Params object
     *
     */
    Params()
    {
        // 加载本地json配置文件
        string path = "../res/config.json";
        std::ifstream fileStr(path);
        if (!fileStr.good())
        {
            std::cout << "Error: Params file path:[" << path << "] not find !!!" << std::endl;
            exit(-1);
        }
        nlohmann::json configs;
        fileStr >> configs;
        try
        {
            config = configs.get<Config>();
        }
        catch (const nlohmann::detail::exception &e)
        {
            std::cerr << "Json Params Parse failed :" << e.what() << std::endl;
            exit(-1);
        }

        mode = FsmMode::NORMAL;                    // 初始化控制模式
        track = make_shared<Track>();              // 赛道线处理
        printf("[OK]: Params initial succeed!!!\n");
    };
    ~Params() {};

    /**
     * @brief 检测斑马线
     *
     */
    bool detectCross(Mat &img,int line,int num)
    {
        Cross = 0;
        cross.clear();

        for (int i = 10; i < COLSIMAGE-10; i++)
        {
            if((img.at<uchar>(line,i-1) == 0 && img.at<uchar>(line,i) == 255)
                ||(img.at<uchar>(line,i-1) == 255 && img.at<uchar>(line,i) == 0))        //黑-->白
            {
                Cross++; 
                cross.push_back(Point(i, line));
            }
                  
        }
        
        if(Cross>num)
            return true;
        else
            return false;
    }
    
    /**
     * @brief 直线判断
     * @param pointsEdge 边线点集
     * @param start 起始行
     * @param end 终止行
     * @return S 小于1为直线
     */
    float Straight_Judge(vector<Point> pointsEdge,int start, int end)     //返回结果小于1即为直线
    {
        int i;
        float S = 0, Sum = 0, Err = 0, k = 0;
        if(pointsEdge.empty())
        {
            return 2;
        }
        if(end>pointsEdge.size()-1)
        {
            return 2;
        }
        
        k = (float)(pointsEdge[start].x - pointsEdge[end].x) / (start - end);
        for (i = 0; i < end - start; i++)
        {
                Err = (pointsEdge[start].x + k * i - pointsEdge[i+start].x)*(pointsEdge[start].x + k * i - pointsEdge[i+start].x);
                Sum += Err;
        }
            S = Sum / (end - start);
        return S;
    }

    /**
     * @brief  丢线检测
     * @param pointsEdge 边线点集
     * @param bool left 方向
     * @param start 起始行
     * @param end 终止行
     * @return bool
     */
    bool loss_judgment(vector<Point> pointsEdge,bool left,uint16_t start,uint16_t end)
    {
        int lossline=0;
        if(pointsEdge.empty())
        {
            return false;
        }
        if(end>pointsEdge.size()-1)
        {
            return false;
        }
        if(left)
        {
            for(int i=start;i<end;i++)
            {
                if(pointsEdge[i].x!=0)
                {
                    lossline++;
                }
            }
            if(lossline==(end-start))
            {
                return true;
            }
        }
        else
        {
            for(int i=start;i<end;i++)
            {
                if(pointsEdge[i].x!=319)
                {
                    lossline++;
                }
            }
            if(lossline==(end-start))
            {
                return true;
            }
        }

        return false;
    }

    int Cross = 0;
    Control ctrl;                       // 车辆控制指令(实时)
    Config config;                      // 系统配置
    FsmMode mode;                       // FSM状态场景
    shared_ptr<Track> track;            // 赛道识别类
    std::vector<PredictResult> results; // AI推理结果
    std::vector<Point> cross; // AI推理结果

    std::vector<int> widths = {
        235, 234, 233, 231, 231, 229, 228, 228, 226, 225,
        224, 223, 222, 220, 220, 218, 217, 216, 215, 214,
        212, 212, 210, 209, 209, 207, 206, 205, 204, 203,
        201, 201, 199, 198, 198, 197, 195, 194, 194, 193,
        191, 191, 190, 188, 187, 186, 185, 184, 183, 182,
        180, 179, 178, 177, 176, 175, 174, 172, 171, 170,
        169, 168, 166, 166, 164, 163, 162, 161, 160, 158,
        158, 156, 155, 154, 153, 152, 150, 150, 148, 147,
        146, 145, 144, 142, 141, 140, 139, 138, 137, 136,
        134, 134, 133, 131, 130, 129, 128, 127, 125, 125,
        123, 122, 122, 120, 119, 118, 118, 116, 115, 113,
        113, 111, 110, 109, 108, 106, 105, 104, 102, 102,
        100, 99, 98, 96, 95, 93, 93, 91, 89, 88,
        87, 86, 84, 84, 82, 81, 80, 79, 77, 77
        };
    
private:
};