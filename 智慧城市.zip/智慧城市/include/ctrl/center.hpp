#pragma once

#include <cmath>
#include <numeric>
#include "utils/tools.hpp"
#include "utils/params.hpp"

/**
 * @brief 控制中心处理类
 *
 */
class Center
{
public:
    /**
     * @brief 中线拟合方式
     */
    enum Style{
        STRIGHT = 0, 
        RIGHT,
        LEFT,
        RP,
        LP,
    };
    Style style = Style::STRIGHT;

    void fitting(shared_ptr<Params> &params);
    void drawImage(shared_ptr<Params> &params, Mat &img);

private:
    int countOut = 0;
    int timeout = 0;

    void showMode(Mat &img, FsmMode mode);
    vector<PointX> centerCompute(vector<PointX> pointsEdge, int side);
    void derailmentCheck(vector<PointX> pointsEdgeLeft, vector<PointX> pointsEdgeRight);
};