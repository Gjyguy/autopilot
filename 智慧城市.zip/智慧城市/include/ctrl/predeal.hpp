#pragma once

#include <fstream>
#include <iostream>
#include <cmath>
#include "utils/tools.hpp"

class Predeal
{
public:
	Predeal(int bin);
	~Predeal() {};
	cv::Mat binaryzation(cv::Mat &img);
	void black_border(cv::Mat &img);
	int binary = -1; // 图像二值化阈值：<0 默认使用大津法

private:
	bool enable = false;  // 图像矫正使能：初始化完成
};