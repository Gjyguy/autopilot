#pragma once

#include <cmath>
#include <numeric>
#include "utils/tools.hpp"

using namespace cv;
using namespace std;

class Track
{
public:
    vector<Point> pointsEdgeLeft;  // 赛道左边缘点集
    vector<Point> pointsEdgeRight; // 赛道右边缘点集
    vector<Point> edgeleft;      // 赛道左边缘点集
	vector<Point> edgeright;    // 赛道右边缘点集
    vector<int> Left_lose_judge;
    vector<int> Right_lose_judge;
    vector<int> Width;
    int edgeLeft_Size;
    int edgeRight_Size;
    int leftlosenum = 0;//左边丢线数
    int rightlosenum = 0;//右边丢线数
    int topline = 0;
    
    int Find_Boundary(Mat& Binaryimg);
    void search(int break_flag, Mat& Binaryimg);
    void ProcessEdgesToSingleLinein(vector<Point> pointsEdgeLeft,vector<Point> pointsEdgeRight);
    void ProcessEdgesToSingleLineout(vector<Point> pointsEdgeLeft,vector<Point> pointsEdgeRight);
    void reset();
    void drawImage(Mat &img);
    void drawImage1(Mat &img);

private:
    Mat imgShare; // 赛道搜索图像
    uint16_t rows = 199;                // 图像行数
	uint16_t cols = 320;                // 图像列数
    int find_Boundary_flag = 0;         // 找到左右起始点标志位
	int mid=cols/2;
};
