#pragma once

#include <cmath>
#include <numeric>
#include "utils/tools.hpp"
#include "utils/params.hpp"

using namespace std;

class Motion
{

public:
    /**
     * @brief 姿态PD控制器
     *
     * @param center 智能车控制中心
     */
    void poseControl(shared_ptr<Params> &params)
    {
        float error = params->ctrl.center - COLSIMAGE / 2; // 图像控制中心转换偏差
        static int errorLast = 0;                          // 记录前一次的偏差
        if (abs(error - errorLast) > COLSIMAGE / 20)       // 16
        {
            error = error > errorLast ? errorLast + COLSIMAGE / 10
                                      : errorLast - COLSIMAGE / 10;
        }


        // if(params->mode == FsmMode::BUSY)
        //     params->ctrl.P=params->config.coneP;
        if (params->mode == FsmMode::PEOPLE) 
            params->ctrl.P=params->config.people_P;
        else if(params->mode == FsmMode::CURVE)
            params->ctrl.P=params->config.curve_P;
        else if(params->mode == FsmMode::SLOW)
            params->ctrl.P=params->config.slow_P;
        else if(params->mode == FsmMode::PARK)
            params->ctrl.P=params->config.park_P;
        else
            params->ctrl.P=params->config.turnP;

        //cout<<"P;"<<params->ctrl.P<<endl;

        int pwmDiff = (error * params->ctrl.P) + (error - errorLast) * params->config.turnD;
        errorLast = error;
        params->ctrl.servo = (uint16_t)(PWMSERVOMID - pwmDiff); // PWM转换

        //舵机限幅
        if (params->ctrl.servo > PWMSERVOMAX)
            params->ctrl.servo = PWMSERVOMAX;
        else if (params->ctrl.servo < PWMSERVOMIN)
            params->ctrl.servo = PWMSERVOMIN;

        //cout<<"error:"<<error<<endl;
        //cout<<"pwm:"<<params->ctrl.servo<<endl;
    }

    /**
     * @brief 变加速控制
     *
     * @param params
     */
    void speedControl(shared_ptr<Params> &params)
    {
        if (params->ctrl.stop) // 停车
        {
            params->ctrl.speed = 0;
            return;
        }
        else if (params->ctrl.curveslow) 
        {
            params->ctrl.speed = 10;
            return;
        }
        else if (params->ctrl.back) 
        {
            params->ctrl.speed = -30;
            return;
        }
        else if (params->ctrl.crossslow) 
        {
            params->ctrl.speed = 30;
            return;
        }
        else if (params->mode == FsmMode::PEOPLE) // 连续弯道速度
        {
            params->ctrl.speed = params->config.speedPeople;
            return;
        }
        else if (params->mode == FsmMode::CURVE) // 连续弯道速度
        {
            params->ctrl.speed = params->config.speedCurve;
            return;
        }
        else if (params->mode == FsmMode::FORK) // 岔路速度
        {
            params->ctrl.speed = params->config.speedFork;
            return;
        }
        else if (params->ctrl.slow) // 减速区速度
        {
            params->ctrl.speed = params->config.speedSlow;
            return;
        }
        else if (params->mode == FsmMode::PARK) // 停车场速度
        {
            params->ctrl.speed = params->config.speedPark;
            return;
        }
        else if (params->mode == FsmMode::BUSY) // 停车场速度
        {
            params->ctrl.speed = params->config.speedBusy;
            return;
        }
        else
        {
           params->ctrl.speed = params->config.speedLow;
        }


    }

    /**
     * @brief 车辆冲出赛道检测（保护车辆）
     *
     * @param track
     * @return true
     * @return false
     */
    void outlineCheck(shared_ptr<Params> &params)
    {
        if (outline) // 已出现
        {
            params->ctrl.stop = true; // 停车
            countRes++;
            if (countRes > 15)
            {
                std::cout << "-----> [Stop] Game over, system exit!!! <-----" << std::endl;
                std::exit(0); // 程序退出
            }
        }
    }

private:
    int countRes = 0;
    int countOut = 0;
    bool outline = false; // 出线标志
};
