#pragma once

#include <iostream> // 输入输出类
#include <stdint.h> // 整型数据类
#include <string>
#include <thread>
#include <cstring>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <cstdio>
#include <unistd.h>
#include <sys/types.h>

using namespace std;

class Client
{
private:
// USB通信帧
#define USB_FRAME_HEAD 0x42 // USB通信帧头
#define USB_FRAME_LENMIN 4  // USB通信帧最短字节长度
#define USB_FRAME_LENMAX 12 // USB通信帧最长字节长度

// USB通信地址
#define USB_ADDR_CARCTRL 1  // 智能车速度+方向控制
#define USB_ADDR_BUZZER 4   // 蜂鸣器音效控制
#define USB_ADDR_LED 5     // LED灯效控制
#define USB_ADDR_KEY 6  // 按键信息

    /**
     * @brief 串口通信结构体
     *
     */
    typedef struct 
    {
        bool start;                             // 开始接收标志
        uint8_t index;                          // 接收序列
        uint8_t buffRead[USB_FRAME_LENMAX];     // 临时缓冲数据
        uint8_t buffFinish[USB_FRAME_LENMAX];   // 校验成功数据
    } SerialStruct;
    
    std::thread threadRes;  // 串口接收子线程
    std::string portname;   // 端口名字
    SerialStruct serialStr; // 串口通信数据结构体
    int socketId = 0;       // 套接字ID
    int countIint = 0;      // 初始化计数器

    /**
     * @brief 32位数据内存对齐/联合体
     *
     */
    typedef union 
    {
       uint8_t buff[4];
       float float32;
       int int32;
    } Bit32Union;
    
    /**
     * @brief 16位数据内存对齐/联合体
     *
     */
    typedef union 
    {
        uint8_t buff[2];
        int int16;
        uint16_t uint16;
    } Bit16Union;

public:
    // 定义构造函数
    Client() {};
    // 定义析构函数
    ~Client() { closeClient(); };
    bool keypress = false; // 按键    

    /**
     * @brief 蜂鸣器音效
     *
     */
    enum Buzzer
    {
        BUZZER_OK = 0,      // 确认
        BUZZER_WARNNING,    // 报警
        BUZZER_FINISH,      // 完成
        BUZZER_DING,        // 提示
        BUZZER_START,       // 开机
    };

    /**
     * @brief 关闭客户端
     *
     */
    void closeClient()
    {
        carControl(0, 1500); // 舵机PWM中值 1500
        close(socketId);
        threadRes.join();
    }

    /**
     * @brief U8转char
     *
     * @param str
     * @param UnChar
     * @param ucLen
     */
    void convertUnCharToStr(char *data, unsigned char *buff)
    {
        int len = sizeof(buff) / sizeof(buff[0]);
        for (int i = 0; i < len; i++)
        {
            // 格式化输str,每unsigned char 转换字符占两位置%x写输%X写输
            sprintf(data + i * 2, "%02x", buff[i]);
        }
    }

    /**
     * @brief 套接字发送数据
     *
     */
    void transmit(uint8_t *buff, int len)
    {
        char data[len];
        memcpy(data, buff, len);     // 拷贝内存数据，防止“\0”数据丢失

        // 发送消息到服务器
        send(socketId, data, len, 0);
    }

    /**
     * @brief 速度+方向控制
     *
     * @param speed 速度：m/s
     * @param servo 方向：PWM（500~2500）
     */
    void carControl(float speed, uint16_t servo)
    {
        countIint++;
        if(countIint >= 50)
            countIint = 50;
        else
            speed = 0.0;    // 初始化速度为0，等待1s发车

        uint8_t buff[11];   // 多发送一个字节
        uint8_t check = 0;  // 校验位
        Bit32Union bit32U;
        Bit16Union bit16U;

        buff[0] = USB_FRAME_HEAD;       // 通信帧头
        buff[1] = USB_ADDR_CARCTRL;     // 地址
        buff[2] = 10;                   // 帧长

        bit32U.float32 = speed;         // X轴线速度
        for (int i = 0; i < 4; i++)
            buff[i+3] = bit32U.buff[i];

        bit16U.uint16 = servo;          // Y轴线速度
        buff[7] = bit16U.buff[0];
        buff[8] = bit16U.buff[1];

        //构造控制数据帧：帧头 + 地址 + 长度 + 速度(4字节) + 舵机值(2字节)。
        for (int i = 0; i < 9; i++)
            check += buff[i];
        buff[9] = check;                // 校验位

        transmit(buff, 11);             // 发送数据
    }

    /**
     * @brief 蜂鸣器音效控制
     *
     * @param sound
     */
    void buzzerSound(Buzzer sound)
    {
        uint8_t buff[6];    // 多发送一个字节
        uint8_t check = 0;  // 校验位

        buff[0] = USB_FRAME_HEAD;   // 帧头
        buff[1] = USB_ADDR_BUZZER;  // 地址
        buff[2] = 5;                // 帧长
        switch (sound)
        {
        case Buzzer::BUZZER_OK: // 确认
            buff[3] = 1;
            break;
        case Buzzer::BUZZER_WARNNING: // 报警
            buff[3] = 2;
            break;
        case Buzzer::BUZZER_FINISH: // 完成
            buff[3] = 3;
            break;
        case Buzzer::BUZZER_DING: // 提示
            buff[3] = 4;
            break;
        case Buzzer::BUZZER_START: // 开机
            buff[3] = 5;
            break;
        }
        
        for (size_t i = 0; i < 4; i++)
            check += buff[i];
        buff[4] = check;

        transmit(buff, 6); // 发送数据
    }

    /**
     * @brief 发送心跳信号
     *
     */
    void sendHeart()
    {
        uint8_t buff[3];   // 多发送一个字节
        transmit(buff, 3); // 发送数据
    }

    /**
     * @brief 启动套接字通信
     *
     * @return true
     * @return false
     */
    bool start(void)
    {
        //创建TCP套接字
        socketId = socket(PF_INET, SOCK_STREAM, 0);
        //检查套接字创建是否成功，失败则输出错误信息并返回false
        if (socketId < 0)
        {
            cout << "socket init error!" << endl;
            return false;
        }
        struct sockaddr_in address;             //定义服务器地址结构体
        memset(&address, 0, sizeof(address));   //将address结构体所有字节清零，确保没有随机数据
        address.sin_family = AF_INET;           //设置地址族为IPv4
        address.sin_port = htons(8899);         //设置端口号为8899
        //将IPv4地址从文本转换为二进制形式
        //IP地址"127.0.0.1"（本地回环地址）转换为二进制形式
        if (inet_pton(AF_INET, "127.0.0.1", &address.sin_addr) <=0)
        {
            std::cerr << "Invalid address/ Address not supported" << std::endl;
            return false;
        }
        //连接到指定的服务器地址，失败则输出错误信息
        if (connect(socketId, (struct sockaddr *)&address, sizeof(address)) <= 0)
        {
            // 获取具体的错误信息
            int error_code = errno;
            cout << "socket connect error! Code: " << error_code 
                << " - " << strerror(error_code) << endl;
            return false;
        }
        //if (connect(socketId, (struct sockaddr *)&address, sizeof(address)) < 0)
        //{
        //    cout << "socket connect error!" << endl;
        //    return false;
        //}
        
        // 启动数据接收子线程
        threadRes = std::thread([this]()
        {
            char buffer[1024] = {0};
            while (1)
            {
                //从套接字读取数据到缓冲区，最多读取1024字节
                int len = read(socketId, buffer, 1024);
                //将接收到的字节数据转换为std::string
                std::string str(buffer);
                //检查接收到的字符串是否包含"Keypress"，如果包含则将keypress标志设为true
                if (str.find("Keypress") != std::string::npos)//按键按下
                    keypress = true;
            }
        });
        return true;
    }
};