#pragma once

#include <iostream>
#include <sys/socket.h> // 套接字编程头文件
#include <netinet/in.h> // Internet地址族定义
#include <unistd.h>     // POSIX操作系统API
#include <string.h>     // 字符串处理
#include "uart.hpp"     // 自定义串口通信头文件

using namespace std;


class Server
{
private:
    int socketId, newSocket;    // 套接字描述符
    struct sockaddr_in address; // 套接字地址结构
    std::thread threadRes;      // 接收数据的子线程
    
    /**
     * @brief 32位数据内存对齐/联合体
     *
     */
    typedef union 
    {
        char buffC[4];
        uint8_t buff[4];
        float float32;
        int int32;
    } Bit32Union;
    
    /**
     * @brief 16位数据内存对齐/联合体
     *
     */
    typedef union 
    {
        char buffC[2];
        uint8_t buff[2];
        int int16;
        uint16_t uint16;
    } Bit16Union;
    
public:
    Server(const std::string &port) : uart(port) {};    // 默认构造函数

    ~Server() // 析构函数 - 自动清理资源
    {     
        closeServer();
    };

    Uart uart;              // 串口通信对象
    int countDrop = 0;      // 客户端掉线计数器
    bool startApp = false;  // 应用启动标志

    /**
     * @brief 启动服务器监听
     *
     */
    bool start()
    {
        // 串口初始化
        if (uart.open() != 0)
        {
            printf("[Error] Uart Open failed!\n");
            return false;
        }
        uart.startReceive(); // 启动数据接收子线程

        // 创建TCP套接字
        if ((socketId = socket(AF_INET, SOCK_STREAM, 0)) == 0)
        {
            perror("socket failed");
            return false;
        }

        // 配置服务器地址和端口
        address.sin_family = AF_INET;           // IPv4
        address.sin_addr.s_addr = INADDR_ANY;   // 监听所有网络接口
        address.sin_port = htons(8899);         // 端口8899，htons转换字节序

        // 绑定套接字到地址
        if (bind(socketId, (struct sockaddr *)&address, sizeof(address)) < 0)
        {
            perror("bind failed");
            return false;
        }

        // 开始监听连接，最大等待队列为3
        if (listen(socketId, 3) < 0)
        {
            perror("listen");
            return false;
        }

        // 启动串口接收子线程
        threadRes = std::thread([this]()
        {
            // 接受客户端连接
            int addrlen = sizeof(address);

            if ((newSocket = accept(socketId, (struct sockaddr *)&address, (socklen_t *)&addrlen)) < 0)
            {
                perror("accept");
                return false;
            }

            while (1) 
            {
              receive(); // 串口接收校验
            }
        });

        return true;
    }


    /**
     * @brief 注销套接字通信
     *
     */
    void closeServer()
    {
        // 关闭套接字
        threadRes.join();
        close(newSocket);
        close(socketId);
        uart.close(); // 串口通信关闭
    }

    /**
     * @brief 接收客户端数据
     *
     */
    void receive()
    {
        char buffer[1024] = {0};    // 接收缓冲区

        // 从客户端接收数据
        int len = recv(newSocket, buffer , 1024, 0);
        if (len <= 0)
        {
            // 客户端已退出
            perror("Server id outting");
            int addrlen = sizeof(address);
            // 重新等待客户端连接
            if((newSocket = accept(socketId, (struct sockaddr *)&address, (socklen_t *)&addrlen)) < 0)
            {
                perror("accept");
                exit(EXIT_FAILURE); // 连接失败则退出程序
            }
        }

        // 客户端正常连接
        startApp = true;    // 设置应用启动标志
        countDrop = 0;      // 重置掉线计数器

        // 发送至串口通信
        if(len >= 4 && len <= 30)
        {
            for(int i= 0; i < len; i++)
            {
                uint8_t u8 = static_cast<uint8_t>(buffer[i]);
                uart.transmitByte(u8);
            }
        }
    }

    /**
     * @brief 发送数据
     *
     */
    void transmit(string data)
    {
        if(!startApp)
            return;

        const char *greeting = data.c_str();
        if(send(newSocket, greeting, strlen(greeting), 0) < 0)
        {
            perror("send failed");
        }
    }
};
