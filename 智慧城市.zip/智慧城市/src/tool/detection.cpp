#include <fstream>            // 文件操作类
#include <iostream>           // 输入输出类
#include <opencv2/opencv.hpp> // OpenCV终端部署
#include "utils/detection.hpp"
#include "../include/com/client.hpp" 

using namespace std;
using namespace cv;

#define COLS_IMG 320 // 摄像头：图像的列数
#define ROWS_IMG 240 // 摄像头：图像的行数

int main(int argc, char const *argv[])
{
    // 打开摄像头
    VideoCapture capture("/dev/video0", CAP_V4L2);
    if (!capture.isOpened())
    {
        cout << "can not open video device " << endl;
        return 1;
    }

    capture.set(CAP_PROP_FOURCC, VideoWriter::fourcc('M','J','P','G'));
    capture.set(CAP_PROP_FRAME_WIDTH, COLS_IMG);  // 设置图像的列数
    capture.set(CAP_PROP_FRAME_HEIGHT, ROWS_IMG); // 设置图像的行数
    capture.set(cv::CAP_PROP_FPS, 120);                  // 设置帧率

    int rate = capture.get(CAP_PROP_FPS);            // 读取图像的帧率
    int width = capture.get(CAP_PROP_FRAME_WIDTH);   // 读取图像的宽度
    int height = capture.get(CAP_PROP_FRAME_HEIGHT); // 读取图像的高度

    cout << "Camera Param: frame rate = " << rate << " width = " << width << " height = " << height << endl;

    // 目标检测类(AI模型文件)
    shared_ptr<Detection> detection = make_shared<Detection>("../res/models/yolov3_mobilenet_v1", 0.3);
    shared_ptr<Client> client;            // TCP客户端通信类
    client = make_shared<Client>();
    client->start();
    while (1)
    {
        Mat img;
        if (!capture.read(img))
        {
            cout << "no video frame" << endl;
            continue;
        }

        // 启动AI推理
        auto preTime = chrono::duration_cast<chrono::milliseconds>(chrono::system_clock::now().time_since_epoch()).count();
        detection->inference(img); // AI推理
        detection->drawBox(img);   // 图像绘制AI结果

        // 帧率计算
        auto startTime = chrono::duration_cast<chrono::milliseconds>(chrono::system_clock::now().time_since_epoch()).count();
        printf(">> FrameTime: %ldms | %.2ffps \n", startTime - preTime, 1000.0 / (startTime - preTime));
        imshow("img", img);
        waitKey(1);
    }
    capture.release();
}
