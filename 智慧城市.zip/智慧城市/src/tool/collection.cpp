#include <fstream>
#include <iostream>
#include <opencv2/highgui.hpp>
#include <opencv2/opencv.hpp>
#include <string>                // 字符串类
#include <sys/stat.h>            // 获取文件属性
#include <sys/types.h>           // 基本系统数据类型
#include "../include/com/uart.hpp"   // 串口通信

using namespace std;
using namespace cv;

#define COLS_IMG 320 // 摄像头：图像的列数
#define ROWS_IMG 240 // 摄像头：图像的行数

typedef enum
{
    cone = 0,
    person = 1,
    icar = 2,
    busy = 3,
    curve = 4,
    limit = 5,
    unlimit = 6,
    stop = 7,
    flow = 8,
    park = 9,
    gate = 10,
    cross = 11,
    fork = 12,
    left = 13,
    choice = 14,
}ImageKind;

int main(int argc, char const *argv[])
{
    // USB转串口的设备名为/dev/ttyUSB0
    shared_ptr<Uart> uart = make_shared<Uart>("/dev/ttyUSB0"); // 初始化串口驱动
    if (uart == nullptr)
    {
        std::cout << "Create Uart-Uart Error!" << std::endl;
        return -1;
    }
    // 串口初始化，打开串口设备及配置串口数据格式
    int ret = uart->open();
    if (ret != 0)
    {
        std::cout << "Uart Open failed!" << std::endl;
        return -1;
    }
    uart->startReceive(); // 启动数据接收子线程
    // 摄像头初始化
    VideoCapture capture("/dev/video0");
    if (!capture.isOpened())
    {
        std::cout << "can not open video device " << std::endl;
        return 1;
    }

    capture.set(CAP_PROP_FOURCC, VideoWriter::fourcc('M','J','P','G'));
    capture.set(CAP_PROP_FRAME_WIDTH, COLS_IMG);  // 设置图像的列
    capture.set(CAP_PROP_FRAME_HEIGHT, ROWS_IMG); // 设置图像的行
    capture.set(cv::CAP_PROP_FPS, 120);                  // 设置帧率

    ImageKind imgkind;
    int ImageKind_Index;
    string imgPath;

    cout <<" cone = 0 \n person = 1 \n icar = 2 \n busy = 3 \n curve = 4 \n limit = 5 \n unlimit = 6 \n stop = 7 \n flow = 8 \n park = 9 \n gate = 10 \n cross = 11 \n fork = 12 \n left = 13 \n choice = 14"<< endl;
    cout << "IMAGE KIND OF COLLECT:";

    cin >> ImageKind_Index;
    imgkind = ImageKind(ImageKind_Index);

    while (true)
    {
        // 读取图像
        Mat frame;
        if (!capture.read(frame))
        {
            break;
        }
            
        // 图像采集
        static int index = 0;
        if(uart->keypress)
        {
            uart->keypress = false;
            switch(imgkind)
            {
                case cone:{ imgPath = "../res/samples/train/cone/cone"; break; }
                case person:{ imgPath = "../res/samples/train/person/person"; break; }
                case icar:{ imgPath = "../res/samples/train/icar/icar"; break; }
                case busy:{ imgPath = "../res/samples/train/busy/busy"; break; }
                case curve:{ imgPath = "../res/samples/train/curve/curve"; break; }
                case limit:{ imgPath = "../res/samples/train/limit/limit"; break; }
                case stop:{ imgPath = "../res/samples/train/stop/stop"; break; }
                case unlimit:{ imgPath = "../res/samples/train/unlimit/unlimit"; break; }
                case flow:{ imgPath = "../res/samples/train/flow/flow"; break; }
                case park:{ imgPath = "../res/samples/train/park/park"; break; }
                case gate:{ imgPath = "../res/samples/train/gate/gate"; break; }
                case cross:{ imgPath = "../res/samples/train/cross/cross"; break; }
                case fork:{ imgPath = "../res/samples/train/fork/fork"; break; }
                case ImageKind::left:{ imgPath = "../res/samples/train/left/left"; break; }
                case choice:{ imgPath = "../res/samples/train/choice/choice"; break; }
            }
            
            string name = ".jpg";
            index++;
            name = imgPath + to_string(index) + ".jpg";
            struct stat buffer;
            if (stat(imgPath.c_str(), &buffer) != 0) // 判断文件夹是否存在
            {
                string command;
                command = "mkdir -p " + imgPath;
                system(command.c_str()); // 利用os创建文件夹
            }
            imwrite(name, frame);
            cout << "Saved image: " << index << ".jpg" << std::endl;
        }

        putText(frame, to_string(index), Point(10, 30), cv::FONT_HERSHEY_TRIPLEX, 1, cv::Scalar(255, 0, 0), 1, CV_AA); // 显示图片保存序号
        imshow("imgFrame", frame);
        if (waitKey(1) == 27)  // 按ESC键退出
        {
            break;
        }
    }

    return 0;
}