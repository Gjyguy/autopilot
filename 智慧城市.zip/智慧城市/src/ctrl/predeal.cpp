#include "ctrl/predeal.hpp"

using namespace cv;
using namespace std;

/**
 * @brief 图像矫正参数初始化
 *
 * @param bin 二值化阈值
 */
Predeal::Predeal(int bin): binary(bin)
{
    // 读取xml中的相机标定参数
    FileStorage file;
    if (file.open("../res/calibration/valid/calibration.xml", FileStorage::READ)) // 读取本地保存的标定文件
    {
        cout << "[OK]: 相机矫正参数初始化成功!!!" << endl; 
        enable = true;
    }
    else
    {
        cout << "[NO]: 打开相机矫正参数失败!!!" << endl;
        enable = false;
    }
}

/**
 * @brief 图像二值化
 *
 * @param img  输入图像
 * @return cv::Mat 二值化图像
 */
cv::Mat Predeal::binaryzation(cv::Mat &img)
{
    cv::Mat imgGray, imgBin;
    cvtColor(img, imgGray, COLOR_BGR2GRAY); // RGB转灰度图

    if (binary < 0)
        threshold(imgGray, imgBin, 0, 255, THRESH_OTSU); //  采用大津法二值化
    else
    {
        if (binary > 255)
            binary = 255;
        threshold(imgGray, imgBin, binary, 255, THRESH_BINARY); // 固定阈值方法
    }

    // 图像转换
    Mat imgInv = Mat::zeros(imgBin.size(), imgBin.type());
    bitwise_not(imgBin, imgInv);

    //return imgBin;
    return imgInv;
}

/**
 * @brief 图像左右黑色边界绘制
 * 
 * @param img 输入二值化图像
 */
void Predeal::black_border(cv::Mat &img)
{
	//绘制竖线
	for(int i=239;i>=0;i--)
	{
		img.at<uchar>(i,0)=0;
		img.at<uchar>(i, 319)=0;
	}
	//绘制横线
	for(int j=0;j<320;j++)
	{
		img.at<uchar>(59,j)=0;
		img.at<uchar>(200, j)=0;
	}

    for(int j=120;j<=200;j++)
	{
        img.at<uchar>(199,j)=255;  
	}
}

