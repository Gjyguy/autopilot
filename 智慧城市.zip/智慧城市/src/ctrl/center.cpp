#include "ctrl/center.hpp"

using namespace cv;
using namespace std;

/**
 * @brief 控制中心计算
 *
 * @param params
 */
void Center::fitting(shared_ptr<Params> &params)
{
    params->ctrl.center = COLSIMAGE / 2; // 控制中心

    params->ctrl.centerEdge.clear();
    vector<Point> v_center(4); // 三阶贝塞尔曲线
    
    switch (style)
    {
        case Style::STRIGHT:
        {
            for(int i=0;i<params->track->edgeright.size();i++)
            {
                params->ctrl.centerEdge.push_back(Point((int)((params->track->edgeright[i].x + params->track->edgeleft[i].x)/2), params->track->edgeright[i].y));
            }
            break;
        }
        case Style::RIGHT:
        {
            for(int i=0;i<params->track->edgeright.size();i++)
            {
                int x=(int)(params->track->edgeright[i].x - params->widths[i]/2);
                if(x < 0)
                    x = 0;
                else if(x > 319)
                    x = 319;
                params->ctrl.centerEdge.push_back(Point(x, params->track->edgeright[i].y));
            }
            break;
        }
        case Style::LEFT:
        {
            for(int i=0;i<params->track->edgeleft.size();i++)
            {
                int x=(int)(params->track->edgeleft[i].x + params->widths[i]/2);
                if(x < 0)
                    x = 0;
                else if(x > 319)
                    x = 319;
                params->ctrl.centerEdge.push_back(Point(x-10, params->track->edgeleft[i].y));
            }
            break;
        }
        case Style::RP:
        {
            for(int i=0;i<params->track->edgeright.size();i++)
            {
                int x=(int)(params->track->edgeright[i].x - params->widths[i]*3/4);
                if(x < 0)
                    x = 0;
                else if(x > 319)
                    x = 319;
                params->ctrl.centerEdge.push_back(Point(x, params->track->edgeright[i].y));
            }
            break;
        }
        case Style::LP:
        {
            cout<<"left"<<endl;
            for(int i=0;i<params->track->edgeright.size();i++)
            {
                int x=(int)(params->track->edgeright[i].x - params->widths[i]/4);
                if(x < 0)
                    x = 0;
                else if(x > 319)
                    x = 319;
                params->ctrl.centerEdge.push_back(Point(x, params->track->edgeright[i].y));
            }
            break;
        }
    } 

    //边线延长
    if(params->ctrl.centerEdge.size()<140)
    {
        int i=params->ctrl.centerEdge.size();
        Point centerlastpoint=params->ctrl.centerEdge[i-1];
        Point leftlastpoint=params->track->edgeleft[i-1];
        Point rightlastpoint=params->track->edgeright[i-1];
        for(;i<140;i++)
        {
            params->ctrl.centerEdge.push_back({centerlastpoint.x,centerlastpoint.y--});
            params->track->edgeright.push_back({319,rightlastpoint.y--});
            params->track->edgeleft.push_back({0,leftlastpoint.y--});
        }
    }

    // 控制中心计算
    if(style==Style::LEFT)
    {
        params->ctrl.forword = params->config.park_forword;
        params->ctrl.center = params->ctrl.centerEdge[params->ctrl.forword].x;
    }
        
    else if(style==Style::RIGHT)
    {
        if(params->mode == FsmMode::FORK)
            params->ctrl.forword = params->config.fork_forword;
        if(params->mode == FsmMode::PARK)
            params->ctrl.forword = 60;
        params->ctrl.center = params->ctrl.centerEdge[params->ctrl.forword].x;
    }
        
    else if(style==Style::STRIGHT)
    {
        if(params->mode == FsmMode::CURVE)
            params->ctrl.forword = params->config.curve_forword;
        else
            params->ctrl.forword = params->config.normolforword;

        params->ctrl.center = params->ctrl.centerEdge[params->ctrl.forword].x;
    }

    else if(style==Style::LP||style==Style::RP)
    {
        params->ctrl.forword = params->config.people_forword;
        params->ctrl.center = params->ctrl.centerEdge[params->ctrl.forword].x;
    }
            

}

/**
 * @brief 显示赛道线识别结果
 *
 * @param img 需要叠加显示的图像
 */
void Center::drawImage(shared_ptr<Params> &params, Mat &img)
{
    // 绘制中心点集
    for (int i = 0; i < params->ctrl.centerEdge.size(); i++)
        circle(img, params->ctrl.centerEdge[i], 1, Scalar(0, 255, 0), -1);

    // 详细控制参数显示
    string str;
    putText(img, to_string(params->ctrl.center), Point(COLSIMAGE / 2 - 10, 0),
            FONT_HERSHEY_PLAIN, 1.2, Scalar(0, 0, 255), 1); // 中心
}

