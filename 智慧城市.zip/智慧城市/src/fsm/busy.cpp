#include "fsm/busy.hpp"

/**
 * @brief Construct a new Fsm Park
 *
 * @param par
 */
FsmBusy::FsmBusy(std::shared_ptr<Params> par)
    : FSMState(FsmMode::BUSY, par)
{
}

/**
 * @brief Destroy the Fsm Park
 *
 */
FsmBusy::~FsmBusy()
{
}

/**
 * @brief 检查状态切换
 *
 * @return FsmMode 切换后的状态
 */
FsmMode FsmBusy::getMode()
{
    if (enable && params->config.busy)
        return FsmMode::BUSY;
    else
        return FsmMode::NORMAL;
}

/**
 * @brief 图形化显示FSM数据
 *
 * @param img
 */
void FsmBusy::show(Mat &img)
{
    if (!enable || params->mode != FsmMode::BUSY)
        return;

    if (resultObs.x > 0 && resultObs.y > 0)
    {
        cv::Rect rect(resultObs.x, resultObs.y, resultObs.width, resultObs.height);
        cv::rectangle(img, rect, cv::Scalar(0, 0, 255), 1);
    }

    putText(img, "[1] Busy", Point(COLSIMAGE / 2 - 50, 20),
            cv::FONT_HERSHEY_TRIPLEX, 0.5, cv::Scalar(0, 255, 0), 0.5);
}

bool FsmBusy::searchCones(Mat &img) 
{
    Rect Cone;
    bool enable=false;

    //锥桶检测
    Mat hsv;
    cvtColor(img, hsv, COLOR_BGR2HSV);

    // 定义红色的HSV范围（红色在HSV中有两个区间）
    Scalar lowerRed1(0, 100, 60);    // 低色调范围
    Scalar upperRed1(10, 255, 255);
    Scalar lowerRed2(160, 100, 60);  // 高色调范围  
    Scalar upperRed2(180, 255, 255);

    Mat mask1, mask2, Mask;
    inRange(hsv, lowerRed1, upperRed1, mask1);
    inRange(hsv, lowerRed2, upperRed2, mask2);
    // 合并两个红色区域的掩码
    Mask = mask1 | mask2;

    vector<vector<Point>> contours;
    findContours(Mask, contours, RETR_EXTERNAL, CHAIN_APPROX_SIMPLE);
                
    int y_Near = 0; // 行坐标
    if (!contours.empty())
    {
        // 选取距离最近的锥桶   
        int a =0;
        int y_Near = 0; // 行坐标
        for (const auto& contour : contours)
        {
            Rect Tempcone = boundingRect(contour);
            if(Tempcone.y>ROWSIMAGE/3&& Tempcone.y+Tempcone.height < ROWSIMAGE- 20&& Tempcone.y > y_Near)
            {
      
                int row = params->track->edgeleft.size() - (Tempcone.y - 60);
                if (row<0||Tempcone.width*Tempcone.height<250) // 太远不管
                {
                    continue;
                }
                int center = Tempcone.x + Tempcone.width / 2;
                //int disLeft = center - params->track->edgeleft[row].x;  //障碍右侧到左边线的水平距离
                //int disRight = params->track->edgeright[row].x - center;  //右边线到障碍左侧的水平距离
                int disLeft = (Tempcone.x+ Tempcone.width ) - params->track->edgeleft[row].x;  //障碍右侧到左边线的水平距离
                int disRight = params->track->edgeright[row].x - Tempcone.x ;  //右边线到障碍左侧的水平距离
                y_Near = Tempcone.y;
                a++;
                //cout<<"面积:"<<Tempcone.width*Tempcone.height<<endl;
                //cout<<"左距离"<<disLeft<<"."<<"右距离"<<disRight<<endl;
                
                //if(disLeft>=0 && disRight>=0)
                if(center>0&&center<320)
                {
                   enable = true;
                   Cone = Tempcone;
                   y_Near = Tempcone.y; 
                   //if (disLeft <= disRight) //[1] 障碍物在赛道内， 且靠左
                   if(center<160)
                   {
                        coneleft = true;
                        coneright =false;
                   }
                   //else if (disLeft > disRight) //[2] 障碍物在赛道内，且靠右
                   else if(center>160)
                   {
                        coneleft = false;
                        coneright = true;
                   }
                   line(img,Point(center,0),Point(center,239),Scalar(0,255,0),2);
                   line(img,Point(0,params->track->edgeleft[row].y),Point(319,params->track->edgeleft[row].y),Scalar(0,255,0),2);
                }
            }
            
        }
        //cout<<"锥桶数量:"<<a<<endl;
    }


    if(enable)
    {
        ResultObs.type = LABEL_CONE;
        ResultObs.x = Cone.x;
        ResultObs.y = Cone.y;
        ResultObs.height = Cone.height;
        ResultObs.width = Cone.width;     
    }

    if(enable)
    {
        Rect rect(ResultObs.x, ResultObs.y, ResultObs.width, ResultObs.height);
        rectangle(img, rect, cv::Scalar(0, 0, 255), 3);
    } 
    return enable;
}

/**
 * @brief 缩减优化车道线（双车道→单车道）
 *
 * @param left
 */
void FsmBusy::curtailTracking(bool left)
{
    if (left) // 向左侧缩进
    {
        for (int i = 0; i < params->track->edgeright.size(); i++)
        {
            params->track->edgeright[i].x = (params->track->edgeright[i].x + params->track->edgeleft[i].x) / 3;
        }
    }
    else // 向右侧缩进
    {
        for (int i = 0; i < params->track->edgeleft.size(); i++)
        {
            params->track->edgeleft[i].x = (params->track->edgeright[i].x + params->track->edgeleft[i].x) / 3;
        }
    }
}

/**
 * @brief 运行FSM状态（循环主程序）
 *
 */
void FsmBusy::run(Mat &img)
{
    if (!params->config.busy) // 该模式未启用
        return;

    // resultObs = PredictResult();
    // if (params->track->edgeleft.size() < ROWSIMAGE / 6 || params->track->edgeright.size() < ROWSIMAGE / 6)//40
    //     return;

    // 施工区标志检测
    for (int i = 0; i < params->results.size(); i++)
    {
        if (params->results[i].type == LABEL_BUSY && params->results[i].y>30 && params->results[i].score>0.7)
        {
            int row = params->track->edgeleft.size() - (params->results[i].y - 60);

            int center = params->results[i].x + params->results[i].width / 2;
            int disLeft = center - params->track->edgeleft[row].x;  //障碍右侧到左边线的水平距离
            int disRight = params->track->edgeright[row].x - center;  //右边线到障碍左侧的水平距离

            if (row>0&&disRight<0) // 太远不管
            {
                cout<<"busy start"<<endl;
                enable = true;
                break;
            }


        }
    }

    if(enable)
    {
        if(params->detectCross(img,150,params->config.cross_Num))
        {
            cout<<"busy exsit"<<endl;
            enable=false;
        }
           
    }

    // if(enable)
    // {
    //     if(coneleft)
    //         curtailTracking(false);
    //     if(coneright)
    //         curtailTracking(true);

    //     if(params->detectCross(img,100,params->config.cross_Num))
    //         enable=false;
    // }

}