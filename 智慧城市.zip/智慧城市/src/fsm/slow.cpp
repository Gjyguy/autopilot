#include "fsm/slow.hpp"

/**
 * @brief Construct a new Fsm Park
 *
 * @param par
 */
FsmSlow::FsmSlow(std::shared_ptr<Params> par)
    : FSMState(FsmMode::SLOW, par)
{
}

/**
 * @brief Destroy the Fsm Park
 *
 */
FsmSlow::~FsmSlow()
{
}

/**
 * @brief 检查状态切换
 *
 * @return FsmMode 切换后的状态
 */
FsmMode FsmSlow::getMode()
{
    // 输出场景状态结果
    if (!params->config.slow || step == Step::NONE)
        return FsmMode::NORMAL;

    else
        return FsmMode::SLOW;
}

/**
 * @brief 图形化显示FSM数据
 *
 * @param img
 */
void FsmSlow::show(Mat &img)
{
    if (params->mode != FsmMode::SLOW)
        return;

    putText(img, "[6] Slow", Point(COLSIMAGE / 2 - 50, 20),
            cv::FONT_HERSHEY_TRIPLEX, 0.5, cv::Scalar(0, 255, 0), 0.5);
}

/**
 * @brief 设置新状态
 *
 * @param step
 */
void FsmSlow::setStep(Step st)
{
    step = st;
    unlimit = false;
    timeout = 0;  // 超时计数器
}

/**
 * @brief 运行FSM状态（循环主程序）
 *
 */
void FsmSlow::run(Mat &img)
{
    if (!params->config.slow) // 该模式未启用
        return;

    switch (step)
    {
        case Step::NONE: // AI标志检测
        {
            params->ctrl.slow = false; // 车辆减速标志
            for (int i = 0; i < params->results.size(); i++)
            {
                if (params->results[i].type == LABEL_LIMIT 
                    && params->results[i].score >0.7
                    && params->results[i].y > 50) // AI识别标志
                {
                    setStep(Step::ENABLE);
                    break;
                }
            }
            break;
        }

        case Step::ENABLE: // 减速阶段
        {
            timeout++;
            params->ctrl.slow = true; // 车辆减速标志

            for (int i = 0; i < params->results.size(); i++)
            {
                if (params->results[i].type == LABEL_LIMIT
                    && params->results[i].score >0.7
                    && params->results[i].y>50) // AI识别标志
                {
                    timeout = 0;
                }
                if (params->results[i].type == LABEL_UNLIMIT 
                    && params->results[i].score >0.7
                    && params->results[i].y>50) // AI识别标志
                {
                    unlimit = true;
                    break;
                }
            }

            cout<<"计时:"<<timeout<<endl;
            if(unlimit)
            {
                cout<<"识别退出"<<endl;
                setStep(Step::NONE);
            }
            if(timeout > params->config.slow_outTime)
            {
                cout<<"超时退出"<<params->config.slow_outTime<<endl;
                setStep(Step::NONE);
            }

            break;
        }
    }
}