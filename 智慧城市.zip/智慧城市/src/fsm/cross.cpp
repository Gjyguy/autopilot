#include "fsm/cross.hpp"

/**
 * @brief Construct a new Fsm Park
 *
 * @param par
 */
FsmCross::FsmCross(std::shared_ptr<Params> par)
    : FSMState(FsmMode::CROSS, par)
{
}

/**
 * @brief Destroy the Fsm Park
 *
 */
FsmCross::~FsmCross()
{
}

/**
 * @brief 检查状态切换
 *
 * @return FsmMode 切换后的状态
 */
FsmMode FsmCross::getMode()
{
    // 输出场景状态结果
    if (!params->config.cross || step == Step::NONE)
        return FsmMode::NORMAL;
    else
        return FsmMode::CROSS;
}

/**
 * @brief 运行FSM状态（循环主程序）
 *
 */
void FsmCross::run(Mat &img)
{
    if (!params->config.cross) // 该模式未启用
        return;

    countInit++; //起点屏蔽计数器
    if (countInit > 999)
        countInit = 999;
    else if (countInit < 10)
        return;

    switch (step)
    {
        case Step::NONE: // AI未识别
        {
            countCross++; // 斑马线屏蔽计数器
            if (countCross > 999)
                countCross = 999;
            if(params->detectCross(img,params->config.cross_Judgment1,params->config.cross_Num) && countCross > params->config.cross_OutTime &&params->ctrl.crosssenable)
                params->ctrl.crossslow=true;
            if(params->detectCross(img,params->config.cross_Judgment2,params->config.cross_Num) && countCross > params->config.cross_OutTime &&params->ctrl.crosssenable)
            {
                time++;
                cout<<"cross:"<<time<<endl;
                params->ctrl.crossslow = false;
                setStep(Step::ENABLE);   
            }
            break;
        }

        case Step::ENABLE: // 场景使能
        {
            params->ctrl.stop = true; // 停车标志
            timeout++; // 场次计数器
            if (timeout >= params->config.cross_ParkTime)
                setStep(Step::NONE); // 设置新状态
            break;
        }
    }     
}

/**
 * @brief 图形化显示FSM数据
 *
 * @param img
 */
void FsmCross::show(Mat &img)
{
    if (params->mode != FsmMode::CROSS)
        return;

    putText(img, "Cross", Point(COLSIMAGE / 2 - 50, 20),
            cv::FONT_HERSHEY_TRIPLEX, 0.5, cv::Scalar(0, 255, 0), 0.5);
}

/**
 * @brief 设置新状态
 *
 * @param step
 */
void FsmCross::setStep(Step st)
{
    step = st;
    timeout = 0;  // 超时计数器
    params->ctrl.stop = false;
    countCross = 0;
}