#include "fsm/fork.hpp"

/**
 * @brief Construct a new Fsm Park
 *
 * @param par
 */
FsmFork::FsmFork(std::shared_ptr<Params> par)
    : FSMState(FsmMode::FORK, par)
{
}

/**
 * @brief Destroy the Fsm Park
 *
 */
FsmFork::~FsmFork()
{
}

/**
 * @brief 检查状态切换
 *
 * @return FsmMode 切换后的状态
 */
FsmMode FsmFork::getMode()
{
    // 输出场景状态结果
    if (!params->config.fork || step == Step::NONE)
        return FsmMode::NORMAL;

    else
        return FsmMode::FORK;
}

/**
 * @brief 图形化显示FSM数据
 *
 * @param img
 */
void FsmFork::show(Mat &img)
{
    if (params->mode != FsmMode::FORK)
        return;

    putText(img, "[4] Fork", Point(COLSIMAGE / 2 - 50, 20),
            cv::FONT_HERSHEY_TRIPLEX, 0.5, cv::Scalar(0, 255, 0), 0.5);
}

/**
 * @brief 设置新状态
 *
 * @param step
 */
void FsmFork::setStep(Step st)
{
    step = st;
}

/**
 * @brief 运行FSM状态（循环主程序）
 *
 */
void FsmFork::run(Mat &img)
{
    if (!params->config.fork) // 该模式未启用
        return;

    switch (step)
    {
        case Step::NONE: // AI标志检测
        {
            if (params->Straight_Judge(params->track->edgeright,10,130) < 1
            && params->track->rightlosenum < 10
            && params->track->leftlosenum > 35) // AI识别标志
            {
                time++;
                cout<<"岔路开始:"<<time<<endl;
                setStep(Step::ENABLE);
                break;
            }
            break;
        }
        case Step::ENABLE: // AI标志检测
        {
            if(params->Straight_Judge(params->track->edgeleft,10,20) < 1
            && !params->loss_judgment(params->track->edgeleft,true,10,20)
            && params->loss_judgment(params->track->edgeleft,true,30,80))
            // if (params->Straight_Judge(params->track->edgeleft,30,90) < 1
            // && params->loss_judgment(params->track->edgeleft,true,30,90))
            {
                cout<<"岔路结束:"<<time<<endl;
                setStep(Step::NONE);
            } 
            break;
        }
    }
}


