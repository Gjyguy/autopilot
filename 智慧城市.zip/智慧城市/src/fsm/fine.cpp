#include "fsm/fine.hpp"

/**
 * @brief Construct a new Fsm Park
 *
 * @param par
 */
FsmFine::FsmFine(std::shared_ptr<Params> par)
    : FSMState(FsmMode::FINE, par)
{
}

/**
 * @brief Destroy the Fsm Park
 *
 */
FsmFine::~FsmFine()
{
}

/**
 * @brief 检查状态切换
 *
 * @return FsmMode 切换后的状态
 */
FsmMode FsmFine::getMode()
{
    // 输出场景状态结果
    if (!params->config.fine || step == Step::NONE)
        return FsmMode::NORMAL;

    else
        return FsmMode::FINE;
}

/**
 * @brief 图形化显示FSM数据
 *
 * @param img
 */
void FsmFine::show(Mat &img)
{
    if (params->mode != FsmMode::FINE)
        return;

    putText(img, "[3] Fine", Point(COLSIMAGE / 2 - 50, 20),
            cv::FONT_HERSHEY_TRIPLEX, 0.5, cv::Scalar(0, 255, 0), 0.5);
}

/**
 * @brief 设置新状态
 *
 * @param step
 */
void FsmFine::setStep(Step st)
{
    step = st;
    countRec = 0; // AI场景识别计数器
    countSes = 0; // 场次计数器
    timeout = 0;  // 超时计数器
}

/**
 * @brief 运行FSM状态（循环主程序）
 *
 */
void FsmFine::run(Mat &img)
{
    if (!params->config.fine) // 该模式未启用
        return;

    switch (step)
    {
        case Step::NONE: // AI未识别
        {
            for (int i = 0; i < params->results.size(); i++)
            {
                if (params->results[i].type == LABEL_STOP 
                    &&params->results[i].y>40
                    &&params->results[i].score > 0.5) // AI识别标志
                {
                    params->ctrl.crosssenable = false;
                    setStep(Step::ENABLE);
                    break;
                }
            }

            break;
        }

        case Step::ENABLE: // 准备停车
        {
            timeout++; // 超时计数器

            for (int i = 0; i < params->results.size(); i++)
            {
                if (params->results[i].type == LABEL_STOP 
                    && params->results[i].score > 0.5) // AI识别标志
                {
                    timeout = 0;
                    break;
                }
            }

            //if (params->detectCross(img,100)) // AI识别标志
            //    timeout = 0;
            
            if (timeout > params->config.fine_Time)
                setStep(Step::STOP);
    
            break;
        }

        case Step::STOP: // 停车
        {
            params->ctrl.stop = true;
            timeout++; // 停车倒计时
            if (timeout > 5)
            {
                std::cout << "-----> [Stop] system exit!!! <-----" << std::endl;
                std::exit(0); // 程序退出
            }
            break;
        }

    }
}