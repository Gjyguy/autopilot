#include "fsm/curve.hpp"

/**
 * @brief Construct a new Fsm Park
 *
 * @param par
 */
FsmCurve::FsmCurve(std::shared_ptr<Params> par)
    : FSMState(FsmMode::CURVE, par)
{
}

/**
 * @brief Destroy the Fsm Park
 *
 */
FsmCurve::~FsmCurve()
{
}

/**
 * @brief 检查状态切换
 *
 * @return FsmMode 切换后的状态
 */
FsmMode FsmCurve::getMode()
{
    // 输出场景状态结果
    if(!params->config.curve || step == Step::NONE)
        return FsmMode::NORMAL;
    
    else
        return FsmMode::CURVE;
}

/**
 * @brief 图形化显示FSM数据
 *
 * @param img
 */
void FsmCurve::show(Mat &img)
{
    if (params->mode != FsmMode::CURVE)
        return;

    putText(img, "[2] Curve", Point(COLSIMAGE / 2 - 50, 20),
        cv::FONT_HERSHEY_TRIPLEX, 0.5, cv::Scalar(0, 255, 0), 0.5);
}

/**
 * @brief 设置新状态
 *
 * @param step
 */
void FsmCurve::setStep(Step st)
{
    step = st;
    params->ctrl.curveslow = false;
    timeout = 0;  // 超时计数器
}

/**
 * @brief 运行FSM状态（循环主程序）
 *
 */
void FsmCurve::run(Mat &img)
{
    if (!params->config.curve) // 该模式未启用
        return;

    if (step == Step::NONE)
    {
        for (int i = 0; i < params->results.size(); i++)
        {
            if (params->results[i].type == LABEL_CURVE && params->results[i].y >15&&params->results[i].score>0.4) // 连续弯标志检测
            {
                setStep(Step::ENABLE); // 设置新状态
                break;
            }
        }
    }    
    else if (step == Step::ENABLE)
    {

        if(params->detectCross(img,100,params->config.cross_Num)
            &&timeout>20)
        {
            cout<<"curve退出"<<endl;
            setStep(Step::NONE); // 设置新状态 
        }

        timeout++;
        if(timeout==30)
            timeout=30;

        if(timeout >= 15 &&params->Straight_Judge(params->track->edgeright,80,130)<1&&params->loss_judgment(params->track->edgeright,false,80,130))
        {
            params->ctrl.curveslow = true;
            cout<<"弯道减速"<<endl;
        }

        if (timeout >= 5 && timeout <= 20)
        {
            //cout<<"buzzer"<<endl;
            params->ctrl.buzzer = true;
        }
        else 
            params->ctrl.buzzer = false;
    }
}