#include "fsm/park.hpp"

/**
 * @brief Construct a new Fsm Park
 *
 * @param par
 */
FsmPark::FsmPark(std::shared_ptr<Params> par)
    : FSMState(FsmMode::PARK, par)
{
}

/**
 * @brief Destroy the Fsm Park
 *
 */
FsmPark::~FsmPark()
{
}

/**
 * @brief 检查状态切换
 *
 * @return FsmMode 切换后的状态
 */
FsmMode FsmPark::getMode()
{
    if (step == Step::NONE || !params->config.park)
        return FsmMode::NORMAL;

    else
        return FsmMode::PARK;
}

/**
 * @brief 设置下阶段
 *
 * @param step
 */
void FsmPark::setStep(Step st)
{
    step = st;    // 停车步骤
    timeout = 0;
}

/**
 * @brief 图形化显示FSM数据
 *
 * @param img
 */
void FsmPark::show(Mat &img)
{
    if (params->mode != FsmMode::PARK)
        return;

    putText(img, "[5] Park", Point(COLSIMAGE / 2 - 50, 20),
            cv::FONT_HERSHEY_TRIPLEX, 0.5, cv::Scalar(0, 255, 0), 0.5);
}

/**
 * @brief 运行FSM状态（循环主程序）
 *
 */
void FsmPark::run(Mat &img)
{
    if (!params->config.park) // 该模式未启用
        return;

    switch (step)
    {
        case Step::NONE: // AI未识别
        {
            for (int i = 0; i < params->results.size(); i++)
            {
                if (params->results[i].type == LABEL_PARK&&params->results[i].y>40&&params->results[i].score>0.5) // AI标志：停车场
                {
                    setStep(Step::ENABLE); // 设置停车场新步骤
                    std::cout << "进入停车场" << std::endl;
                    break;
                }
            }
            break;
        }

        /*
        case Step::ENABLE: // 停车场使能
        {
            params->ctrl.crosssenable = false;
            for (int i = 0; i < params->results.size(); i++)
            {
                if (params->results[i].type == LABEL_GATE && params->results[i].y > 100) // AI标志：左转直行
                {
                    std::cout << params->results[i].y << std::endl;
                    setStep(Step::FORKIN); // 设置停车场新步骤
                    std::cout << "道闸" << std::endl;
                    break;
                }
            }
            break;
        }
        */

        case Step::ENABLE: // 停车场使能
        {
            params->ctrl.crosssenable = false;
            if (gate) // AI标志：左转直行
            {
                if(gate_y>params->config.gate_Y1)
                {
                    setStep(Step::FORKIN); // 设置停车场新步骤
                    std::cout << "道闸" << std::endl;
                }
            }
            break;
        }

        case Step::FORKIN: // 入库岔路转向
        {
            timeout++;
            params->ctrl.stop=true;
            std::cout << "停车:" << timeout <<std::endl;
            if (timeout > params->config.gate_Time1)
            {
                params->ctrl.stop=false;
                std::cout << "前进" <<std::endl;
                setStep(Step::TRACKIN); // 设置停车场新步骤
            }
            break;
        }

        case Step::TRACKIN: // 入库巡线中
        {
            crossRecognition(img,false);
            if(params->track->edgeleft.size()>30)
            {
                for(int i=10;i<params->track->edgeleft.size()-15;i++)
                {
                    if((params->track->edgeleft[i].x-params->track->edgeleft[i-1].x)>10
                        &&params->track->Left_lose_judge[i-1]
                        &&params->loss_judgment(params->track->edgeleft,true,i,i+10)
                        &&params->Straight_Judge(params->track->edgeleft,i-10,i-1)<1)
                    {
                        ptA=params->track->edgeleft[i];
                        //std::cout << ptA.y <<std::endl;
                        circle(img,params->track->edgeleft[i], 10, Scalar(0,0,255), FILLED);
                        circle(img,params->track->edgeleft[i-1], 10, Scalar(0,0,255), FILLED);

                        if(ptA.y>params->config.park_Y)
                        {
                            std::cout << ptA.y <<std::endl;
                            setStep(Step::ENTER);       // 设置停车场新步骤
                            std::cout << "入车库" <<std::endl;
                        }
                            
                        break;
                    }
                }
            }
            break;
        }

        case Step::ENTER: // 驶入停车位
        {
            //std::cout << "截止行:" << params->track->topline << std::endl;
            if(params->track->topline>params->config.park_Topline)
            {
                std::cout << "截止行:" << params->track->topline << std::endl;
                setStep(Step::PARKING); // 停车完成
            }   
            break;
        }

        case Step::PARKING: // 停车
        {
            params->ctrl.stop = true; // 停车标志
            timeout++;
            if (timeout > params->config.park_Time)        // 停车计时
                setStep(Step::EXIT); // 出库
            break;
        }

        case Step::EXIT: // 出库
        {
            params->ctrl.stop = false; // 停车标志
            params->ctrl.back = true;  // 倒车
    
            if(params->track->edgeleft.size()>130)
            {
                for(int i=1;i<params->track->edgeleft.size();i++)
                {
                    //if((params->track->edgeleft[i].x-params->track->edgeleft[i-1].x)>10
                    //    &&params->track->Left_lose_judge[i-1])
                    if((params->track->edgeleft[i].x-params->track->edgeleft[i-1].x)>10
                    &&params->track->Left_lose_judge[i-1]
                    &&params->loss_judgment(params->track->edgeleft,true,i,i+10)
                    &&params->Straight_Judge(params->track->edgeleft,i-10,i-1)<1)
                    {
                        ptA=params->track->edgeleft[i];
                        std::cout << ptA.y <<std::endl;
                        circle(img,params->track->edgeleft[i], 10, Scalar(0,0,255), FILLED);
                        //if(ptA.x<params->config.park_X)
                        //{
                        setStep(Step::TRACKOUT); // 停车完成
                        std::cout << "ok" <<std::endl; 
                        //}
                        break;
                    }
                }
            }
            break;
        }

        /*
        case Step::TRACKOUT: // 出库巡线
        {
            params->ctrl.back = false;  // 倒车
            crossRecognition(img);
            for (int i = 0; i < params->results.size(); i++)
            {
                if (params->results[i].type == LABEL_GATE && params->results[i].y > 100) // AI标志：左转直行
                {
                    std::cout << params->results[i].y << std::endl;
                    setStep(Step::FORKOUT); // 设置停车场新步骤
                    std::cout << "道闸" << std::endl;
                    break;
                }
            }
            break;
        }
        */
       case Step::TRACKOUT: // 出库巡线
        {
            params->ctrl.back = false;  // 倒车
            crossRecognition(img,true);
            if (gate) // AI标志：左转直行
            {
                if(gate_y>params->config.gate_Y2)
                {
                    setStep(Step::FORKOUT); // 设置停车场新步骤
                    std::cout << "道闸" << std::endl;
                }
            }
            break;
        }

        case Step::FORKOUT: // 出库岔路转向
        {
            timeout++;
            std::cout << "停车:" << timeout <<std::endl;
            params->ctrl.stop=true;
            if (timeout > params->config.gate_Time2)
            {
                params->ctrl.stop=false;
                std::cout << "前进" <<std::endl;
                setStep(Step::END); // 设置停车场新步骤
            }
            break;
        }

        case Step::END: // 结束
        {
            if ((params->Straight_Judge(params->track->edgeright,15,100) < 1 && params->track->rightlosenum < 15) 
            || (params->Straight_Judge(params->track->edgeleft,30,70) < 1 && params->loss_judgment(params->track->edgeleft,true ,30,70)))
            {
                std::cout << "结束" <<std::endl;
                setStep(Step::NONE); // 设置停车场新步骤
            }
            break;
        }

    }
}

void FsmPark::reset(void)
{
    right_up = 0;
    right_down = 0;
    left_up = 0;
    left_down = 0;
}

bool FsmPark::crossRecognition(Mat &img,bool Left)
{       
    //复位 
    reset();

    //寻找角点
    if(Left)
        Searchleft(img);
    else
        Searchright(img);

    //太近舍去
    if (abs(params->track->edgeleft[left_up].y - params->track->edgeleft[left_down].y) < 10) left_up = 0;
    if (abs(params->track->edgeright[right_up].y - params->track->edgeright[right_down].y) < 10) right_up = 0;
    if(params->track->edgeleft[left_down].x==0) left_down=0;

    //处理
    Left_deal();
    Right_deal();

    return right_up || right_down;
}

void FsmPark::Searchleft(Mat &img)
{
    if(params->track->edgeleft.size()>55)
    {
        for (int i = 10; i <= 55; i ++)
        {
            //下角点
            if (params->track->edgeleft[i].x - params->track->edgeleft[i - 5].x <= -20 &&
                params->track->edgeleft[i - 5].x >= params->track->edgeleft[i - 10].x)
            {
                if (left_down == 0)
                    left_down = i - 5;
                else if (params->track->edgeleft[i - 5].x > params->track->edgeleft[left_down].x && abs(params->track->edgeleft[i - 5].y - params->track->edgeleft[left_down].y) < 10)
                    left_down = i - 5;
            }

            if (2 * params->track->edgeleft[i - 5].x - params->track->edgeleft[i].x - params->track->edgeleft[i - 10].x >= 10 &&
                params->track->edgeleft[i - 5].x - params->track->edgeleft[i].x >= 2 &&
                params->track->edgeleft[i - 5].x - params->track->edgeleft[i - 10].x >= 2)
            {
                if (left_down == 0)
                    left_down = i - 5;
                else if (params->track->edgeleft[i - 5].x > params->track->edgeleft[left_down].x && abs(params->track->edgeleft[i - 5].y - params->track->edgeleft[left_down].y) < 10)
                    left_down = i - 5;
            }
        }


        for (int i = 55; i < params->track->edgeleft.size() - 20; i ++)
        {
        //上角点
            if (params->track->edgeleft[i-4].x - params->track->edgeleft[i - 5].x >= -3 &&
                params->track->edgeleft[i-4].x - params->track->edgeleft[i - 5].x <= 3&&
                params->track->edgeleft[i - 5].x - params->track->edgeleft[i - 10].x >= 20&&
                params->Straight_Judge(params->track->edgeleft,i-5,i+5)<1&&
                params->loss_judgment(params->track->edgeleft,true,i-5,i+5))
            {
                if (left_up == 0)
                    left_up = i - 5;
                else if (params->track->edgeleft[i].x > params->track->edgeleft[left_up].x)
                    left_up = i - 5;
            }
        }

        if(left_down!=0)
            circle(img,params->track->edgeleft[left_down],5,Scalar(0,255,0),FILLED);
        if(left_up!=0)
        {
            circle(img,params->track->edgeleft[left_up-5],5,Scalar(0,255,0),FILLED);
            circle(img,params->track->edgeleft[left_up],5,Scalar(0,255,0),FILLED);
        }    
           
    }
}

void FsmPark::Searchright(Mat &img)
{
    if(params->track->edgeright.size()>20)
    {
        for (int i = 10; i < params->track->edgeright.size()-10; i ++)
        {
            if (params->track->edgeright[i].x - params->track->edgeright[i - 5].x >= 20 &&
                params->track->edgeright[i - 5].y <= params->track->edgeright[i - 10].y)
                {
                    if (right_down == 0)
                        right_down = i - 5;
                    else if (params->track->edgeright[i - 5].x < params->track->edgeright[right_down].x && abs(params->track->edgeright[i - 5].y - params->track->edgeright[right_down].y) < 10)
                        right_down = i - 5;
                }
            
            if (2 * params->track->edgeright[i - 5].x - params->track->edgeright[i].x - params->track->edgeright[i - 10].x <= -10 &&
                params->track->edgeright[i - 5].x - params->track->edgeright[i].x <= -2 &&
                params->track->edgeright[i - 5].x - params->track->edgeright[i - 10].x <= -2)
            {
                if (right_down == 0)
                    right_down = i - 5;
                else if (params->track->edgeright[i - 5].x < params->track->edgeright[right_down].x && abs(params->track->edgeright[i - 5].y - params->track->edgeright[right_down].y) < 10)
                    right_down = i - 5;
            }

            if (params->track->edgeright[i-4].x - params->track->edgeright[i - 5].x <=3 &&
                params->track->edgeright[i-4].x - params->track->edgeright[i - 5].x >= -3 &&
                params->track->edgeright[i - 5].x - params->track->edgeright[i - 10].x <= -20)
            {
                if (right_up == 0)
                    right_up = i - 5;
                else if (params->track->edgeright[i].x < params->track->edgeright[right_up].x)
                    right_up = i - 5;
            }
        }

        if(right_down!=0)
            circle(img,params->track->edgeright[right_down],5,Scalar(0,255,0),FILLED);
        if(right_up!=0) 
            circle(img,params->track->edgeright[right_up],5,Scalar(0,255,0),FILLED);
    }   
}

void FsmPark::Left_deal()
{
    if (left_down != 0 && left_up != 0 && params->track->edgeleft[left_up].y < params->track->edgeleft[left_down].y)
    {
        if (params->track->edgeleft[left_down].y != params->track->edgeleft[left_up].y)
        {
            int temp_x;
            for (int i = left_down + 1; i < left_up; i ++)
            {
                temp_x = params->track->edgeleft[left_down].x +
                    (params->track->edgeleft[left_down].y - params->track->edgeleft[i].y) *
                    (params->track->edgeleft[left_up].x - params->track->edgeleft[left_down].x) /
                    (params->track->edgeleft[left_down].y - params->track->edgeleft[left_up].y);

                if (temp_x < 0)
                    params->track->edgeleft[i].x = 0;
                else if (temp_x >= COLSIMAGE)
                    params->track->edgeleft[i].x = COLSIMAGE - 1;
                else 
                    params->track->edgeleft[i].x = temp_x;
            }
        }
    }
    else
    {
        if (left_down != 0)
        {
            uint8_t left_begin = left_down > 20 ? left_down - 20 : 0;
            while (abs(params->track->edgeleft[left_begin].x - params->track->edgeleft[left_down].x) > 10 &&
                   left_begin < left_down - 10) left_begin ++;
            if (params->track->edgeleft[left_begin].y != params->track->edgeleft[left_down].y)
            {
                int temp_x;
                for (int i = left_down + 1; i < params->track->edgeleft.size(); i ++)
                {
                    temp_x = params->track->edgeleft[left_down].x +
                        (params->track->edgeleft[left_down].y - params->track->edgeleft[i].y) *
                        (params->track->edgeleft[left_down].x - params->track->edgeleft[left_begin].x) /
                        (params->track->edgeleft[left_begin].y - params->track->edgeleft[left_down].y);
                    if (temp_x < 0) params->track->edgeleft[i].x = 0;
                    else if (temp_x >= COLSIMAGE) params->track->edgeleft[i].x = COLSIMAGE - 1;
                    else params->track->edgeleft[i].x = temp_x;
                }
            }
        }
        if (left_up != 0)
        {
            uint8_t left_end = left_up + 20 < params->track->edgeleft.size() - 1 ? left_up + 20 : params->track->edgeleft.size() - 1;
            while (abs(params->track->edgeleft[left_end].x - params->track->edgeleft[left_up].x) > 10 &&
                   left_end > left_up + 10) left_end --;
            if (params->track->edgeleft[left_up].y != params->track->edgeleft[left_end].y)
            {
                int temp_x;
                for (int i = left_up - 1; i >= 0; i --)
                {
                    temp_x = params->track->edgeleft[left_up].x -
                        (params->track->edgeleft[i].y - params->track->edgeleft[left_up].y) *
                        (params->track->edgeleft[left_end].x - params->track->edgeleft[left_up].x) /
                        (params->track->edgeleft[left_up].y - params->track->edgeleft[left_end].y);
                    if (temp_x < 0) params->track->edgeleft[i].x = 0;
                    else if (temp_x >= COLSIMAGE) params->track->edgeleft[i].x = COLSIMAGE - 1;
                    else params->track->edgeleft[i].x = temp_x;
                }
            }
        }
    }
}

void FsmPark::Right_deal()
{
    if (right_down != 0 && right_up != 0 && params->track->edgeright[right_up].y < params->track->edgeright[right_down].y)
    {
        if (params->track->edgeright[right_down].y != params->track->edgeright[right_up].y)
        {
            int temp_x;
            for (int i = right_down + 1; i < right_up; i ++)
            {
                temp_x = params->track->edgeright[right_down].x +
                    (params->track->edgeright[right_down].y - params->track->edgeright[i].y) *
                    (params->track->edgeright[right_up].x - params->track->edgeright[right_down].x) /
                    (params->track->edgeright[right_down].y - params->track->edgeright[right_up].y);

                if (temp_x < 0)
                    params->track->edgeright[i].x = 0;
                else if (temp_x >= COLSIMAGE)
                    params->track->edgeright[i].x = COLSIMAGE - 1;
                else 
                    params->track->edgeright[i].x = temp_x;
            }
        }
    }
    else
    {
        if (right_down != 0)
        {
            uint8_t right_begin = right_down > 20 ? right_down - 20 : 0;
            while (abs(params->track->edgeright[right_begin].x - params->track->edgeright[right_down].x) > 10 &&
                   right_begin < right_down - 10) right_begin ++;
                     int temp_x;
                    for (int i = right_down + 1; i < params->track->edgeright.size(); i ++)
                    {
                        temp_x = params->track->edgeright[right_down].x +
                            (params->track->edgeright[right_down].y - params->track->edgeright[i].y) *
                            (params->track->edgeright[right_down].x - params->track->edgeright[right_begin].x) /
                            (params->track->edgeright[right_begin].y - params->track->edgeright[right_down].y);
                        if (temp_x < 0) params->track->edgeright[i].x = 0;
                        else if (temp_x >= COLSIMAGE) params->track->edgeright[i].x = COLSIMAGE - 1;
                        else params->track->edgeright[i].x = temp_x;
                    }
        }
    
        if (right_up != 0)
        {
            uint8_t right_end = right_up + 20 < params->track->edgeright.size() - 1 ? right_up + 20 : params->track->edgeright.size() - 1;
            while (abs(params->track->edgeright[right_end].x - params->track->edgeright[right_up].x) > 10 &&
                   right_end > right_up + 10) right_end --;
                    int temp_x;
                    for (int i = right_up - 1; i >= 0; i --)
                    {
                        temp_x = params->track->edgeright[right_up].x -
                            (params->track->edgeright[i].y - params->track->edgeright[right_up].y) *
                            (params->track->edgeright[right_end].x - params->track->edgeright[right_up].x) /
                            (params->track->edgeright[right_up].y - params->track->edgeright[right_end].y);
                        if (temp_x < 0) params->track->edgeright[i].x = 0;
                        else if (temp_x >= COLSIMAGE) params->track->edgeright[i].x = COLSIMAGE - 1;
                        else params->track->edgeright[i].x = temp_x;
                    }        
        }
    }
}

bool FsmPark::searchgate(Mat &img) 
{
    Rect Gate;
    bool enable=false;
    gate =false;
    gate_y =0;
    //锥桶检测
    Mat hsv;
    cvtColor(img, hsv, COLOR_BGR2HSV);
    // 定义黄色的HSV范围
    Scalar lowerYellow(15, 100, 60);
    Scalar upperYellow(35, 255, 255);
    
    Mat Mask;
    inRange(hsv, lowerYellow, upperYellow, Mask);

    vector<vector<Point>> contours;
    findContours(Mask, contours, RETR_EXTERNAL, CHAIN_APPROX_SIMPLE);
    
    //
    line(img,Point(50,60),Point(50,200),Scalar(0,0,255),2);
    line(img,Point(250,60),Point(250,200),Scalar(0,0,255),2);

    line(img,Point(50,60),Point(250,60),Scalar(0,0,255),2);
    line(img,Point(50,200),Point(250,200),Scalar(0,0,255),2);

    int y_Near = 0; // 行坐标
    if (!contours.empty())
    {
        // 选取距离最近的锥桶   
        int num =0;
        //int y_Near = 0; // 行坐标
        int x_Near = 0; // 行坐标
        for (const auto& contour : contours)
        {
            Rect Tempcone = boundingRect(contour);
            //高度限制

            //if(Tempcone.y>60&&Tempcone.y<200&& Tempcone.y > y_Near)
            if(Tempcone.y>60&&Tempcone.y<200&& Tempcone.x > x_Near)
            {
            
                //if (Tempcone.width*Tempcone.height<250||Tempcone.width*Tempcone.height>1000) // 太远不管
                if (Tempcone.width*Tempcone.height<100||Tempcone.width*Tempcone.height>1000) // 太远不管
                {
                    continue;
                }
                //宽度限制
                int center = Tempcone.x + Tempcone.width / 2;
                x_Near = Tempcone.x;
                num++;

                
                
                if(Tempcone.x<200&&Tempcone.x>50)
                {
                   enable = true;
                   gate = true;
                   Gate = Tempcone;
                   x_Near = Tempcone.x; 
                   gate_y = Tempcone.y; 
                   //cout<<"面积:"<<Tempcone.width*Tempcone.height<<endl;
                   //cout<<"x:"<<Tempcone.x<<endl;
                   //line(img,Point(center,0),Point(center,239),Scalar(0,0,255),2);
                   //line(img,Point(0,Gate.y),Point(319,Gate.y),Scalar(255,0,0),2);
                   Rect rect(Gate.x, Gate.y, Gate.width, Gate.height);
                   circle(img,Point{Gate.x,Gate.y},10,Scalar(0,0,255),FILLED);
                   rectangle(img, rect, cv::Scalar(255, 0, 0), 3);
                }
            }
            
        }
        //cout<<"Gate数量:"<<num<<endl;
        
    }
    //cout<<"gate:"<<gate<<endl;  
    
   
    //cout<<"y:"<<gate_y<<endl; 
    //cout<<endl;
    /*
    if(enable)
    {
        Rect rect(Gate.x, Gate.y, Gate.width, Gate.height);
        circle(img,Point{Gate.x,Gate.y},10,Scalar(0,0,255),FILLED);
        rectangle(img, rect, cv::Scalar(255, 0, 0), 3);
    } 
        */
    return enable;
}