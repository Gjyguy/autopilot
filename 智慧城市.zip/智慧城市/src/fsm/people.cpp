#include "fsm/people.hpp"

/**
 * @brief Construct a new Fsm People
 *
 * @param par
 */
FsmPeople::FsmPeople(std::shared_ptr<Params> par)
    : FSMState(FsmMode::PEOPLE, par)
{
}

/**
 * @brief Destroy the Fsm People
 *
 */
FsmPeople::~FsmPeople()
{
}

/**
 * @brief 检查状态切换
 *
 * @return FsmMode 切换后的状态
 */
FsmMode FsmPeople::getMode()
{
    // 输出场景状态结果
    if (!params->config.people || step == Step::NONE)
        return FsmMode::NORMAL;

    else
        return FsmMode::PEOPLE;
}

/**
 * @brief 图形化显示FSM数据
 *
 * @param img
 */
void FsmPeople::show(Mat &img)
{
    if (params->mode != FsmMode::PEOPLE)
        return;

    putText(img, "[6] People", Point(COLSIMAGE / 2 - 50, 20),
            cv::FONT_HERSHEY_TRIPLEX, 0.5, cv::Scalar(0, 255, 0), 0.5);
}

/**
 * @brief 设置新状态
 *
 * @param step
 */
void FsmPeople::setStep(Step st)
{
    step = st;
    timeout = 0;  // 超时计数器
}

/**
 * @brief 运行FSM状态（循环主程序）
 *
 */
void FsmPeople::run(Mat &img)
{
    if (!params->config.people) // 该模式未启用
        return;

    switch (step)
    {
        case Step::NONE: // AI标志检测
        {
            if(purple_enable || red_enable)
                setStep(Step::ENABLE);
            //params->ctrl.personslow = false; // 车辆减速标志
            // for (int i = 0; i < params->results.size(); i++)
            // {
            //     if (params->results[i].type == LABEL_PERSON 
            //         && params->results[i].score >0.4
            //         && params->results[i].y > 50) // AI识别标志
            //     {
            //         if(params->results[i].x > 160)
            //             dir = true;
            //         else 
            //             dir = false;

            //         setStep(Step::ENABLE);
            //         break;
            //     }
            // }
            break;
        }

        case Step::ENABLE: // 减速阶段
        {
            red_enable =false;
            purple_enable =false;
            timeout++;
            //cout<<"person:"<<timeout<<endl;
            params->ctrl.personslow = true; // 车辆减速标志
            //curtailTracking(dir);
            if(timeout >= params->config.people_time)
            {
                left = false;
                right = false;
                params->ctrl.personslow = false;
                cout<<"行人结束"<<endl;
                setStep(Step::NONE);
            }
            break;
        }
    }
}

bool FsmPeople::find_purple(Mat &img)
{
    Rect purple;  
    purple_enable = false;

    Mat hsv;
    cvtColor(img, hsv, COLOR_BGR2HSV);

    // 定义紫色的HSV范围
    // 注意：OpenCV中H范围是0-180（对应0-360度的一半）
    // 紫色HSV范围大约在280-320度，对应OpenCV的140-160
    Scalar lowerPurple(130, 50, 50);    // H:130, S:50, V:50
    Scalar upperPurple(160, 255, 255);  // H:160, S:255, V:255

    Mat purpleMask;
    inRange(hsv, lowerPurple, upperPurple, purpleMask);

    // 可选的：应用形态学操作去除噪声
    Mat kernel = getStructuringElement(MORPH_RECT, Size(5, 5));
    morphologyEx(purpleMask, purpleMask, MORPH_OPEN, kernel);
    morphologyEx(purpleMask, purpleMask, MORPH_CLOSE, kernel);

    vector<vector<Point>> contours;
    findContours(purpleMask, contours, RETR_EXTERNAL, CHAIN_APPROX_SIMPLE);

    if (!contours.empty())
    {
        // // 合并所有轮廓点
        vector<Point> allPoints;
        for (const auto& contour : contours) {
            allPoints.insert(allPoints.end(), contour.begin(), contour.end());
        }
        
        // 方法2：使用凸包连接所有轮廓
        vector<Point> hullPoints;
        convexHull(allPoints, hullPoints);
        purple = boundingRect(hullPoints);

        // 计算整个区域的最小外接矩形
        //purple = boundingRect(allPoints);
        if(purple.y>ROWSIMAGE/4&& (purple.y+purple.height) < 180)
        {
            int row = params->track->edgeleft.size() - (purple.y+purple.height - 60);

            if (row<0||purple.width*purple.height>2000 ||purple.width*purple.height<200) // 太远不管
            {
               return false;
            }
            int center = purple.x + purple.width / 2;
            int disLeft = center - params->track->edgeleft[row].x;  //障碍右侧到左边线的水平距离
            int disRight = params->track->edgeright[row].x - center;  //右边线到障碍左侧的水平距离
    
            if(disLeft>=0 && disRight>=0)
            {
                purple_enable = true;
    
                if (disLeft <= disRight) //[1] 障碍物在赛道内， 且靠左
                {
                    left = true;
                    dir = false;
                    cout<<"左"<<endl;
                }
                else if (disLeft > disRight) //[2] 障碍物在赛道内，且靠右
                {
                    right = true;
                    dir = true; 
                    cout<<"右"<<endl;
                }
    
            }
    
            if(purple_enable)
            {
                params->config.purple_count = true;
                cout<<"方向:"<<dir<<endl;
                cout<<"purple面积:"<<purple.width*purple.height<<endl;
                cout<<"左距离"<<disLeft<<"."<<"右距离"<<disRight<<endl;
                rectangle(img, purple, cv::Scalar(255, 0, 0), 3);
            }
        }
    }
    return purple_enable;
}

bool FsmPeople::find_red(Mat &img)
{
    Rect red;  
    red_enable = false;

    Mat hsv;
    cvtColor(img, hsv, COLOR_BGR2HSV);

    // 定义紫色的HSV范围
    // 注意：OpenCV中H范围是0-180（对应0-360度的一半）
    // 紫色HSV范围大约在280-320度，对应OpenCV的140-160
    // 红色范围1
    Scalar lowerRed1(0, 100, 100);
    Scalar upperRed1(10, 255, 255);
    
    // 红色范围2  
    Scalar lowerRed2(160, 100, 100);
    Scalar upperRed2(179, 255, 255);
    
    Mat mask1, mask2;
    inRange(hsv, lowerRed1, upperRed1, mask1);
    inRange(hsv, lowerRed2, upperRed2, mask2);
    
    Mat redMask = mask1 | mask2;

    // 可选的：应用形态学操作去除噪声
    // Mat kernel = getStructuringElement(MORPH_RECT, Size(5, 5));
    // morphologyEx(redMask, redMask, MORPH_OPEN, kernel);
    // morphologyEx(redMask, redMask, MORPH_CLOSE, kernel);

    vector<vector<Point>> contours;
    findContours(redMask, contours, RETR_EXTERNAL, CHAIN_APPROX_SIMPLE);

    // line(img,Point(30,100),Point(30,200),Scalar(0,0,255),2);
    // line(img,Point(290,100),Point(290,200),Scalar(0,0,255),2);

    // line(img,Point(30,100),Point(290,100),Scalar(0,0,255),2);
    // line(img,Point(30,200),Point(290,200),Scalar(0,0,255),2);

    if (!contours.empty())
    {
        vector<Point> allPoints;
        
        // 定义Y值过滤条件
        int y_min_threshold = 100;    // Y坐标最小值阈值
        int y_max_threshold = 200;    // Y坐标最大值阈值（假设图像高度为480）
        // 定义x值过滤条件
        int x_min_threshold = 30;    // Y坐标最小值阈值
        int x_max_threshold = 290;    // Y坐标最大值阈值（假设图像高度为480）

        // 方法1：根据外接矩形位置过滤
        for (const auto& contour : contours)
        {
            Rect bbox = boundingRect(contour);
            int row = params->track->edgeleft.size() - (bbox.y+red.height - 60);

            // 过滤条件：外接矩形中心Y值在有效范围内，且面积足够大
            int center_y = bbox.y + bbox.height / 2;
            int center_x = bbox.x + bbox.width / 2;
            int disLeft = center_x - params->track->edgeleft[row].x;  //障碍右侧到左边线的水平距离
            int disRight = params->track->edgeright[row].x - center_x;  //右边线到障碍左侧的水平距离

            // 检查条件：中心Y在范围内，且面积大于阈值
            if (center_y >= y_min_threshold 
            &&  center_y <= y_max_threshold 
            &&  row > 0
            && disLeft > 0
            && disRight > 0) 
            {  
                allPoints.insert(allPoints.end(), contour.begin(), contour.end());
            }
        }
        
        // 方法2：使用凸包连接所有轮廓
        if (!allPoints.empty())
        {
            vector<Point> hullPoints;
            convexHull(allPoints, hullPoints);
            red = boundingRect(hullPoints);

            // 计算整个区域的最小外接矩形
 
            if(red.y>ROWSIMAGE/4&& red.y < 180)
            {
                int row = params->track->edgeleft.size() - (red.y+red.height - 60);
    
                if (row<0||red.width*red.height>1000 ||red.width*red.height<100) // 太远不管
                {
                   return false;
                }
                int center = red.x + red.width / 2;
                int disLeft = center - params->track->edgeleft[row].x;  //障碍右侧到左边线的水平距离
                int disRight = params->track->edgeright[row].x - center;  //右边线到障碍左侧的水平距离
        
                if(disLeft>=0 && disRight>=0)
                {
                    red_enable = true;
        
                    if (disLeft <= disRight) //[1] 障碍物在赛道内， 且靠左
                    {
                        left = true;
                        dir = false;
                        cout<<"red左"<<endl;
                    }
                    else if (disLeft > disRight) //[2] 障碍物在赛道内，且靠右
                    {
                        right = true;
                        dir = true; 
                        cout<<"red右"<<endl;
                    }
        
                }
        
                if(red_enable)
                {
                    params->config.red_count = true;
                    cout<<"方向:"<<dir<<endl;
                    cout<<"red面积:"<<red.width*red.height<<endl;
                    cout<<"左距离"<<disLeft<<"."<<"右距离"<<disRight<<endl;
                    rectangle(img, red, cv::Scalar(255, 0, 0), 3);
                }
            }
        }
        
    }
    return red_enable;
}


/**
 * @brief 缩减优化车道线（双车道→单车道）
 *
 * @param left
 */
void FsmPeople::curtailTracking(bool left)
{
    if (left) // 向左侧缩进
    {
        for (int i = 0; i < params->track->edgeright.size(); i++)
        {
            params->track->edgeright[i].x = (params->track->edgeright[i].x + params->track->edgeleft[i].x) / 2;
        }
    }
    else // 向右侧缩进
    {
        for (int i = 0; i < params->track->edgeleft.size(); i++)
        {
            params->track->edgeleft[i].x = (params->track->edgeright[i].x + params->track->edgeleft[i].x) / 2;
        }
    }
}