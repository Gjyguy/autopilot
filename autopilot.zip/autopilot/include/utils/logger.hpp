#pragma once

#include <chrono>
#include <ctime>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <sstream>
#include <string>

class Logger 
{
private:
    std::string name;
    std::ofstream logFile;
    bool hasFile;

    /**
     * @brief 获取当前时间
     *
     */
    std::string getCurrentTime()
    {
        auto now = std::chrono::system_clock::now();    // 获取当前时间点
        auto time = std::chrono::system_clock::to_time_t(now);  // 转换为time_t格式
        std::tm tm;
        localtime_r(&time, &tm);    // 线程安全的时间转换（Linux特有）
        std::ostringstream oss;
        // 计算毫秒部分
        auto milliseconds = std::chrono::duration_cast<std::chrono::milliseconds>(now.time_since_epoch()) % 1000;
        oss << "[" << "\033[32m" << std::put_time(&tm, "%Y-%m-%d %H:%M:%S") << "." 
            << std::setfill('0') << std::setw(3) << milliseconds.count() << "\033[0m"
            << "\033[36m " << name << "\033[0m" << "]";
        return oss.str();
    }

public:
    Logger(const std::string &name, const std::string &filePath = "")
        : name(name), hasFile(false)
    {
        if (!filePath.empty())
        {
            logFile.open(filePath, std::ios::app);
            hasFile = logFile.is_open();
        }
    }

    ~Logger()
    {
        if (hasFile)
            logFile.close();
    }

    // Support move semantics (支持移动语义)
    Logger(Logger &&) = default;
    Logger &operator=(Logger &&) = default;

    template <typename... Args> void operator()(Args... args)
    {
        std::stringstream ss;
        ss << getCurrentTime() << " ";
        ((ss << args << " "), ...);
        ss.seekp(-1, std::ios_base::end); // Remove the last space
        ss << std::endl;

        std::cout << ss.str();
        if (hasFile) 
        {
            logFile << ss.str();
            logFile.flush();
        }
    }

    // Warning
    template <typename... Args> void warning(Args... args)
    {
        std::stringstream ss;
        ss << getCurrentTime() << " ";
        ss << "\033[33m";
        ((ss << args << " "), ...);
        ss.seekp(-1, std::ios_base::end); // Remove the last space
        ss << "\033[0m" << std::endl;

        std::cout << ss.str();
        if (hasFile) {
            logFile << ss.str();
            logFile.flush();
        }
    }

    // Error
    template <typename... Args> void error(Args... args)
    {
        std::stringstream ss;
        ss << getCurrentTime() << " ";
        ss << "\033[31m";
        ((ss << args << " "), ...);
        ss.seekp(-1, std::ios_base::end); // Remove the last space
        ss << "\033[0m" << std::endl;

        std::cout << ss.str();
        if (hasFile) {
            logFile << ss.str();
            logFile.flush();
        }
    }
    
    // Info
    template <typename... Args> void info(Args... args)
    {
        std::stringstream ss;
        ss << getCurrentTime() << " ";
        ss << "\033[34m";
        ((ss << args << " "), ...);
        ss.seekp(-1, std::ios_base::end); // Remove the last space
        ss << "\033[0m" << std::endl;

        std::cout << ss.str();
        if (hasFile) {
            logFile << ss.str();
            logFile.flush();
        }
    }
};