#pragma once

#include <fstream>            // 文件操作类
#include <iostream>           // 输入输出类
#include <opencv2/opencv.hpp> // OpenCV终端部署
#include "utils/json.hpp"
#include "utils/tools.hpp"
#include "utils/show.hpp"

using namespace std;
using namespace cv;

class Show
{
private:
    bool enable = false;   // 显示窗口使能
    int sizeWindow = 1;    // 窗口数量
    cv::Mat imgShow;       // 窗口图像
public:
    /**
     * @brief 显示窗口初始化
     *
     * @param size 窗口数量(1~7)
     */
    Show(const int size)
    {
        if (size <= 0 || size > 7)
            return;

        cv::namedWindow("ICAR", WINDOW_NORMAL);     // 图像名称
        cv::resizeWindow("ICAR", COLSIMAGE*2+1 , ROWSIMAGE*2+1); // 分辨率
        imgShow = cv::Mat::zeros(  ROWSIMAGE*2+1 ,COLSIMAGE*2+1 ,CV_8UC3);
        enable = true;
        sizeWindow = size;
    };
    ~Show() {};

    /**
     * @brief 设置新窗口属性
     *
     * @param index 窗口序号
     * @param name 窗口名称
     * @param img 显示图像
     */
    void setNewWindow(int index, string name, Mat img)
    {
        // 数据溢出保护
        if (!enable || index <= 0 || index > sizeWindow)
            return;

        if (img.cols <= 0 || img.rows <= 0)
            return;

        Mat imgDraw = img.clone();

        if (imgDraw.type() == CV_8UC1) // 非RGB类型的图像
            cvtColor(imgDraw, imgDraw, cv::COLOR_GRAY2BGR);

        // 限制图片标题长度
        string text = "[" + to_string(index) + "] ";
        if (name.length() > 15)
            text = text + name.substr(0, 15);
        else
            text = text + name;

        putText(imgDraw, text, Point(10, 20), cv::FONT_HERSHEY_TRIPLEX, 0.5, cv::Scalar(255, 0, 0), 0.5);

        if (index <= 2)
        {
            Rect placeImg = Rect(COLSIMAGE * (index - 1), 0, COLSIMAGE, ROWSIMAGE);
            imgDraw.copyTo(imgShow(placeImg));
        }

        else
        {
            Rect placeImg = Rect(COLSIMAGE * (index - 3), ROWSIMAGE, COLSIMAGE, ROWSIMAGE);
            imgDraw.copyTo(imgShow(placeImg));
        }
    }

    /**
     * @brief 融合后的图像显示
     *
     */
    void show(void)
    {
        if (enable)  
            imshow("ICAR", imgShow);
    }
};
