#pragma once

#include <fstream>
#include <iostream>
#include <cmath>
#include "utils/tools.hpp"

class Predeal
{
public:
	Predeal(int bin);
	~Predeal() {};
	cv::Mat binaryzation(cv::Mat &img);
	void mapPerspective(float x, float y, float loc[2], uint8_t mode);
	void black_border(cv::Mat &img);
	int binary = -1; // 图像二值化阈值：<0 默认使用大津法
	// 原图 -> 俯视  透视矩阵
	cv::Mat warpMatrix =
		(cv::Mat_<float>(3, 3) << 4.830985915493104, 7.481690140845294,
 		-559.9154929577662, 1.3374922084896e-14, 14.74647887323986,
 		-725.1690140845323, 7.62235112648736e-17, 0.05070422535211418, 1);

private:
	bool enable = false;  // 图像矫正使能：初始化完成
};