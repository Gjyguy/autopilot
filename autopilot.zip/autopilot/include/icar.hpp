#pragma once

#include "utils/show.hpp"
#include "ctrl/predeal.hpp"
#include "utils/detection.hpp"
#include "ctrl/motion.hpp"

using namespace std;
using namespace cv;

class Icar
{
private:
    shared_ptr<Predeal> predeal;          // 图像预处理类
    shared_ptr<Params> params;            // 车辆状态参数（FSM共享传递）
    shared_ptr<cv::VideoCapture> capture; // Opencv相机类
    shared_ptr<Show> show;                // 初始化UI显示窗口

public:
    /**
     * @brief 参数初始化
     *
     */
    Icar()
    { 
        params = make_shared<Params>();                        // 初始化参数
        predeal = make_shared<Predeal>(params->config.binary); // 图像预处理类
        
        // 相机初始化
        // USB摄像头初始化
        if (params->config.debug)
            capture = make_shared<cv::VideoCapture>(params->config.video); // 打开本地视频
        else
            capture = make_shared<cv::VideoCapture>("/dev/video0"); // 打开摄像头

        if (!capture->isOpened())
        {
            printf("[Error]: Can not open video device!!!\n");
            exit(-1);
        }

        capture->set(CAP_PROP_FOURCC, VideoWriter::fourcc('M','J','P','G'));
        capture->set(cv::CAP_PROP_FRAME_WIDTH, COLSCAMERA);  // 设置图像分辨率
        capture->set(cv::CAP_PROP_FRAME_HEIGHT, ROWSCAMERA); // 设置图像分辨率
        capture->set(cv::CAP_PROP_FPS, 120);                  // 设置帧率

        if (params->config.show)
            show = make_shared<Show>(4); // 调试UI初始化

        int rate = capture->get(CAP_PROP_FPS);            // 读取图像的帧率
        int width = capture->get(CAP_PROP_FRAME_WIDTH);   // 读取图像的宽度
        int height = capture->get(CAP_PROP_FRAME_HEIGHT); // 读取图像的高度

        printf("[OK]: 把风吹到北京!!!\n");
        cout << "[OK]: " << "Camera Param: frame rate = " << rate << " width = " << width << " height = " << height << endl;
    };
    ~Icar() {};

    /**
     * @brief 程序主循环
     *
     */
    void running()
    {
        //[01] 视频源读取
        cv::Mat img;
        
        if (!capture->read(img))
            return;
            
        cv::Mat img1=img.clone();
        //[02] 图像存储
        if (params->config.saveImg && !params->config.debug) // 存储原始图像
            savePicture(img);

        //[03] 图像预处理
        cv::Mat imgBin;
        imgBin = predeal->binaryzation(img); // 图像二值化
        predeal->black_border(imgBin);

        //[04] 赛道识别
        params->track->reset();
        params->track->search(600,imgBin);
        params->track->ProcessEdgesToSingleLine(params->track->pointsEdgeLeft,params->track->pointsEdgeRight);
        params->track->drawImage1(img);
        params->track->drawImage(img1);
        if (params->config.show) // 综合显示调试UI窗口
        {
            show->setNewWindow(1, "AI", img);
            show->setNewWindow(2, "Bin", imgBin);
            show->setNewWindow(3, "P1", img1);
            //show->setNewWindow(4, "P2", imgBin);
            show->show();        // 显示综合绘图
            waitKey(1);
        }
               
    }

};
