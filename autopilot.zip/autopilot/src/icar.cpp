#include <fstream>
#include <iostream>
#include <stdio.h>
#include <string.h>
#include <opencv2/highgui.hpp>
#include <opencv2/opencv.hpp>
#include "../include/icar.hpp"   // 串口通信
#include "../include/utils/logger.hpp"

using namespace std;
using namespace cv;

int main(int argc, char const *argv[])
{
    Icar icar;

    Logger logger("智慧城市", "/root/workspace/autopilot/log/example.log");
    logger("开始调车");

    while (1)
    {
      icar.running(); // 系统主线程
    }

    return 0;
}
