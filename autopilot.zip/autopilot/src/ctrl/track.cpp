#include "ctrl/track.hpp"

using namespace cv;
using namespace std;

/**
 * @brief 寻找左右起始点
 * 
 * @param Binaryimg 输入二值化图像
 */
int Track::Find_Boundary(Mat& Binaryimg)
{
    find_Boundary_flag = 0;
    
    // 左起始点搜索
    for (int m = mid; m >= 0; m--)
    {
        if (Binaryimg.at<uchar>(rows , m) == 0 && 
            Binaryimg.at<uchar>(rows , m + 1) == 255&&
            Binaryimg.at<uchar>(rows , m + 2) == 255)
        {
            pointsEdgeLeft.push_back(Point(m, rows));
            find_Boundary_flag++;
            break;
        }
    }
    
    // 右起始点搜索
    for (int n = mid; n < cols; n++)
    {
        if (Binaryimg.at<uchar>(rows , n) == 0 &&
            Binaryimg.at<uchar>(rows , n - 1) == 255&&
            Binaryimg.at<uchar>(rows , n - 2) == 255)
        {
            pointsEdgeRight.push_back(Point(n, rows));
            find_Boundary_flag++;
            break;
        }
    }
  
    if(find_Boundary_flag == 2) 
    {
        mid = (int)(pointsEdgeLeft[0].x + pointsEdgeRight[0].x)/2;
    }

    return find_Boundary_flag;
}

/**
 * @brief 边界搜索
 * @param break_flag 边线循环次数
 * @param Binaryimg	输入二值化图像
 */
void Track::search(int break_flag, Mat& Binaryimg)
{

    if (Find_Boundary(Binaryimg) == 2)
    {
        int left = 0;//统计左边总共的长度
        int right = 0;//统计右边总共的长度

        //定义八个邻域
        vector<Point> seeds_left =
        {
              { -1, 1 }, { 0, 1 }, { 1, 1 },
              { 1, 0 },            { 1, -1 },
              { 0, -1 },{ -1, -1 },{ -1, 0 }
        };
        //{-1,-1},{0,-1},{+1,-1},6 5 4      这个是逆时针
        //{-1, 0},       {+1, 0},7   3
        //{-1,+1},{0,+1},{+1,+1},0 1 2

        vector<Point> seeds_right =
        {
            {1, 1},{0,1},{-1,1},
            {-1,0},      {-1,-1},
            {0,-1},{1,-1},{1,0},
        };
        //{-1,-1},{0,-1},{+1,-1},4 5 6       这个是顺时针
        //{-1, 0},       {+1, 0},3   7
        //{-1,+1},{0,+1},{+1,+1},2 1 0

        int direction_left = 3;//左边线的方向  0-7
        int direction_right = 3;//右边线的方向  0-7

        bool should_break = false;

        //开启邻域循环
        for (; break_flag > 0; break_flag--)//最大循环次数
        {
            //搜索左边线
            if(pointsEdgeLeft[left].y >= pointsEdgeRight[right].y&&pointsEdgeLeft[left].y>59)
            {
            for (int j = 0; j < 8; j++)
            {
                if (direction_left < 0) { direction_left += 8; }
                else if (direction_left >= 8) { direction_left -= 8; }
                Point serch_filds = { 0,0 };
                serch_filds.x = pointsEdgeLeft[left].x + seeds_left[direction_left].x;
                serch_filds.y = pointsEdgeLeft[left].y + seeds_left[direction_left].y;

                if (Binaryimg.at<uchar>(serch_filds) == 0)//黑
                {
                    pointsEdgeLeft.push_back(serch_filds);
                    left++;
                    direction_left -= 2;  //如果找到黑色的点 就会改变他的方向
                    // 检查相遇条件
                    if (!pointsEdgeRight.empty() && 
                        pointsEdgeLeft.back() == pointsEdgeRight.back())
                    {
                        should_break = true;
                    }                 
                    break;
                }
                direction_left++;  //不是黑色 方向加1
            }
                if (should_break) break;
            }
            //搜索右边线
            if(pointsEdgeRight[right].y >= pointsEdgeLeft[left-1].y&&pointsEdgeRight[right].y>59)
            {
            for (int j = 0; j < 8; j++)
            {
                if (direction_right < 0) { direction_right += 8; }
                else if (direction_right >= 8) { direction_right -= 8; }
                Point serch_filds = { 0,0 };
                serch_filds.x = pointsEdgeRight[right].x + seeds_right[direction_right].x;
                serch_filds.y = pointsEdgeRight[right].y + seeds_right[direction_right].y;

                if (Binaryimg.at<uchar>(serch_filds) == 0)//黑
                {
                    pointsEdgeRight.push_back(serch_filds);
                    right++;
                    direction_right -= 2;  //如果找到黑色的点 就会改变他的方向
                    // 检查相遇条件
                    if (!pointsEdgeLeft.empty() && 
                        pointsEdgeRight.back() == pointsEdgeLeft.back())
                    {
                        should_break = true;
                    }
                    break;
                }
                direction_right++;  //不是黑色 方向加1
            }
                if (should_break) break;
            }

            if (should_break) break;
        }
    }
}

void Track::ProcessEdgesToSingleLine(vector<Point> pointsEdgeLeft,vector<Point> pointsEdgeRight) 
{
    // 处理右侧点，每行取最左边的点（x最小），且Y <= 200
    unordered_map<int, int> rightMap; // key: y, value: 最小x
    for (const Point& pt : pointsEdgeRight) {
        int y = pt.y;
        if (y > 199) continue; // 新增：跳过Y大于200的点
        int x = pt.x;
        if (rightMap.find(y) == rightMap.end()) {
            rightMap[y] = x;
        } else {
            if (x < rightMap[y]) rightMap[y] = x;
        }
    }

    // 提取y并降序排序（仅保留Y <= 200的点）
    vector<int> rightYs;
    for (const auto& pair : rightMap) {
        rightYs.push_back(pair.first);
    }
    sort(rightYs.begin(), rightYs.end(), greater<int>());

    // 生成edgeright
    edgeright.clear();
    for (int y : rightYs) {
        edgeright.emplace_back(rightMap[y], y);
    }

    // 处理左侧点，每行取最右边的点（x最大），且Y <= 200
    unordered_map<int, int> leftMap; // key: y, value: 最大x
    for (const Point& pt : pointsEdgeLeft) {
        int y = pt.y;
        if (y > 199) continue; // 新增：跳过Y大于200的点
        int x = pt.x;
        if (leftMap.find(y) == leftMap.end()) {
            leftMap[y] = x;
        } else {
            if (x > leftMap[y]) leftMap[y] = x;
        }
    }

    // 提取y并降序排序（仅保留Y <= 200的点）
    vector<int> leftYs;
    for (const auto& pair : leftMap) {
        leftYs.push_back(pair.first);
    }
    sort(leftYs.begin(), leftYs.end(), greater<int>());

    // 生成edgeleft
    edgeleft.clear();
    for (int y : leftYs) {
        edgeleft.emplace_back(leftMap[y], y);
    }

    if(edgeleft.size()==141&&edgeright.size()==141)
    {
        edgeleft.resize(140);
        edgeright.resize(140);
    }
    
    //赛道信息
    for (int i = 0; i < edgeleft.size(); i++)
    {
        //左边线
        if(edgeleft[i].x==0)
        {
            leftlosenum++;
            Left_lose_judge.push_back(1);
        }
        else
        {
            Left_lose_judge.push_back(0);
        }
        //右边线
        if(edgeright[i].x==319)
        {
            rightlosenum++;
            Right_lose_judge.push_back(1);
        } 
        else
        {
            Right_lose_judge.push_back(0);
        }
        //赛道宽度
        Width.push_back(edgeright[i].x-edgeleft[i].x);
        //cout<<"第"<<i<<"行宽度:"<<Width[i]<<endl;
    }

    edgeLeft_Size=edgeleft.size();
    edgeRight_Size=edgeright.size();

}

void Track::reset()
{
    pointsEdgeLeft.clear();  // 赛道左边缘点集
    pointsEdgeRight.clear(); // 赛道右边缘点集
}

/**
 * @brief 显示赛道线识别结果
 *
 * @param img 需要叠加显示的图像
 */
void Track::drawImage(Mat &img)
{
    for (int i = 0; i < edgeleft.size(); i++)
        circle(img, edgeleft[i], 1, Scalar(255,0,0), 1);

    for (int i = 0; i < edgeright.size(); i++)
        circle(img, edgeright[i], 1, Scalar(255,0,0), 1);
}

void Track::drawImage1(Mat &img)
{
    for (int i = 0; i < pointsEdgeLeft.size(); i++)
        circle(img, pointsEdgeLeft[i], 1, Scalar(255,0,0), 1);

    for (int i = 0; i < pointsEdgeRight.size(); i++)
        circle(img, pointsEdgeRight[i], 1, Scalar(255,0,0), 1);
}