/**
 * @file vofa_client.hpp
 * @brief VOFA+ TCP通信客户端
 * @author Your Name
 * @version 1.0
 */

 #include <iostream>
 #include <string>
 #include <cstring>
 #include <sys/socket.h>
 #include <arpa/inet.h>
 #include <unistd.h>
 #include <vector>
 #include <thread>
 #include <chrono>
 #include <math.h>
 
 class VofaClient {
 private:
     int socket_fd;
     bool connected;
     std::string server_ip;
     int server_port;
     std::thread reconnect_thread;
     bool stop_reconnect;
 
 public:
     /**
      * @brief 构造函数
      * @param ip VOFA+服务器IP地址，默认为127.0.0.1
      * @param port VOFA+服务器端口，默认为1347
      */
     VofaClient(const std::string& ip = "192.168.31.47", int port = 1347) 
         : socket_fd(-1), connected(false), server_ip(ip), server_port(port), stop_reconnect(false) {
     }
 
     /**
      * @brief 析构函数
      */
     ~VofaClient() {
         disconnect();
     }
 
     /**
      * @brief 连接到VOFA+服务器
      * @return 连接成功返回true，否则返回false
      */
     bool connectToServer() {
         // 创建socket
         socket_fd = socket(AF_INET, SOCK_STREAM, 0);
         if (socket_fd < 0) {
             std::cerr << "Error creating socket" << std::endl;
             return false;
         }
 
         // 设置服务器地址
         struct sockaddr_in server_addr;
         memset(&server_addr, 0, sizeof(server_addr));
         server_addr.sin_family = AF_INET;
         server_addr.sin_port = htons(server_port);
         
         if (inet_pton(AF_INET, server_ip.c_str(), &server_addr.sin_addr) <= 0) {
             std::cerr << "Invalid address/ Address not supported" << std::endl;
             close(socket_fd);
             return false;
         }
 
         // 连接服务器
         if (connect(socket_fd, (struct sockaddr*)&server_addr, sizeof(server_addr)) < 0) {
             std::cerr << "Connection to VOFA+ failed" << std::endl;
             close(socket_fd);
             return false;
         }
 
         connected = true;
         std::cout << "Connected to VOFA+ at " << server_ip << ":" << server_port << std::endl;
         
         // 启动自动重连线程
         stop_reconnect = false;
         reconnect_thread = std::thread(&VofaClient::autoReconnect, this);
         
         return true;
     }
 
     /**
      * @brief 断开与VOFA+服务器的连接
      */
     void disconnect() {
         stop_reconnect = true;
         connected = false;
         
         if (reconnect_thread.joinable()) {
             reconnect_thread.join();
         }
         
         if (socket_fd >= 0) {
             close(socket_fd);
             socket_fd = -1;
         }
         
         std::cout << "Disconnected from VOFA+" << std::endl;
     }
 
     /**
      * @brief 发送浮点数数据（使用JustFloat协议）
      * @param data 浮点数数据向量
      * @return 发送成功返回true，否则返回false
      */
     bool sendFloatData(const std::vector<float>& data) {
         if (!connected || socket_fd < 0) {
             std::cerr << "Not connected to VOFA+" << std::endl;
             return false;
         }
 
         // JustFloat协议：直接发送浮点数，最后加上0x00 0x00 0x80 0x7F
         std::vector<uint8_t> buffer;
         
         // 添加浮点数数据
         for (float value : data) {
             uint8_t* bytes = reinterpret_cast<uint8_t*>(&value);
             for (int i = 0; i < 4; i++) {
                 buffer.push_back(bytes[i]);
             }
         }
         
         // 添加帧尾：0x00 0x00 0x80 0x7F
         buffer.push_back(0x00);
         buffer.push_back(0x00);
         buffer.push_back(0x80);
         buffer.push_back(0x7F);
 
         // 发送数据
         ssize_t bytes_sent = send(socket_fd, buffer.data(), buffer.size(), 0);
         if (bytes_sent < 0) {
             std::cerr << "Failed to send data to VOFA+" << std::endl;
             connected = false;
             return false;
         }
 
         return true;
     }
 
     /**
      * @brief 发送字符串数据
      * @param data 字符串数据
      * @return 发送成功返回true，否则返回false
      */
     bool sendStringData(const std::string& data) {
         if (!connected || socket_fd < 0) {
             std::cerr << "Not connected to VOFA+" << std::endl;
             return false;
         }
 
         ssize_t bytes_sent = send(socket_fd, data.c_str(), data.length(), 0);
         if (bytes_sent < 0) {
             std::cerr << "Failed to send data to VOFA+" << std::endl;
             connected = false;
             return false;
         }
 
         return true;
     }
 
     /**
      * @brief 检查连接状态
      * @return 连接状态
      */
     bool isConnected() const {
         return connected;
     }
 
     /**
      * @brief 设置服务器地址
      * @param ip 服务器IP地址
      * @param port 服务器端口
      */
     void setServer(const std::string& ip, int port) {
         server_ip = ip;
         server_port = port;
     }
 
 private:
     /**
      * @brief 自动重连线程函数
      */
     void autoReconnect() {
         while (!stop_reconnect) {
             std::this_thread::sleep_for(std::chrono::seconds(1));
             
             if (!connected && !stop_reconnect) {
                 std::cout << "Attempting to reconnect to VOFA+..." << std::endl;
                 if (connectToServer()) {
                     std::cout << "Reconnected to VOFA+" << std::endl;
                 }
             }
         }
     }
 };
 
 // 使用示例
 int main() {
     VofaClient vofa;
     
     // 连接到VOFA+
     if (!vofa.connectToServer()) {
         std::cerr << "Failed to connect to VOFA+" << std::endl;
         return -1;
     }
 
     // 模拟数据发送
     for (int i = 0; i < 10000; i++) {
         // 创建测试数据
         std::vector<float> data;
         data.push_back(static_cast<float>(2.0));           // 时间或索引
         data.push_back(static_cast<float>(sin(i * 0.1))); // 正弦波
         data.push_back(static_cast<float>(4.0)); // 余弦波
         data.push_back(static_cast<float>(5.0));      // 斜坡信号
         
         // 发送数据
         if (!vofa.sendFloatData(data)) {
            std::cerr << "Failed to send data" << std::endl;
            break;
         }
         ///vofa.sendStringData("abc");
         std::cout << "Sent data: " << i << std::endl;
         
         // 等待一段时间
         std::this_thread::sleep_for(std::chrono::milliseconds(10));
     }
     
     vofa.disconnect();
     return 0;
 }